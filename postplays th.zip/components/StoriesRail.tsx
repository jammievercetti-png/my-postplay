
import React from 'react';
import { Story, UserProfile } from '../types';
import { PlusIcon, LiveIcon } from './Icons';

interface StoriesRailProps {
  stories: Story[];
  liveUsers?: UserProfile[]; // Users currently live
  className?: string;
  onStoryClick: (index: number) => void;
  onLiveClick: (userId: string) => void;
}

export const StoriesRail: React.FC<StoriesRailProps> = ({ stories, liveUsers = [], className, onStoryClick, onLiveClick }) => {
  return (
    <div className={`w-full overflow-x-auto no-scrollbar py-4 pl-4 bg-transparent z-20 ${className}`}>
      <div className="flex gap-4">
        {/* Your Story Button */}
        <div className="flex flex-col items-center gap-1 cursor-pointer group flex-shrink-0">
          <div className="relative w-16 h-16">
            <div className="w-16 h-16 rounded-full p-[2px] border-2 border-gray-300 border-dashed group-hover:border-solid transition-all">
               <img src="https://picsum.photos/seed/me/100" className="w-full h-full rounded-full object-cover" />
            </div>
            <div className="absolute bottom-0 right-0 bg-[#800020] rounded-full p-1 border-2 border-white">
               <PlusIcon className="w-3 h-3 text-white" />
            </div>
          </div>
          <span className="text-[11px] font-medium text-white/80 group-hover:text-white drop-shadow-md">You</span>
        </div>

        {/* Live Users First */}
        {liveUsers.map((user) => (
          <div key={user.id} onClick={() => onLiveClick(user.id)} className="flex flex-col items-center gap-1 cursor-pointer transition-transform active:scale-95 flex-shrink-0">
            <div className="relative w-16 h-16 rounded-full p-[3px] bg-gradient-to-tr from-[#fe2c55] to-orange-500 animate-pulse">
              <div className="w-full h-full rounded-full border-2 border-black bg-black overflow-hidden relative">
                <img src={user.avatar} className="w-full h-full object-cover opacity-90" alt={user.username} />
              </div>
              <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 bg-[#fe2c55] text-white text-[8px] font-black px-1.5 py-0.5 rounded-sm border border-black">
                LIVE
              </div>
            </div>
            <span className="text-[11px] font-medium text-white/80 truncate w-16 text-center drop-shadow-md">{user.username}</span>
          </div>
        ))}

        {/* Stories */}
        {stories.map((story, index) => (
          <div key={story.id} onClick={() => onStoryClick(index)} className="flex flex-col items-center gap-1 cursor-pointer transition-transform active:scale-95 flex-shrink-0">
            <div className={`w-16 h-16 rounded-full p-[3px] ${story.isSeen ? 'bg-gray-500' : 'bg-gradient-to-tr from-yellow-400 via-[#800020] to-purple-600'}`}>
              <div className="w-full h-full rounded-full border-2 border-black bg-black overflow-hidden">
                <img src={story.avatar} className="w-full h-full object-cover" alt={story.username} />
              </div>
            </div>
            <span className="text-[11px] font-medium text-white/80 truncate w-16 text-center drop-shadow-md">{story.username}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
