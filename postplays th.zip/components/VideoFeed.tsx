
import React, { useRef, useEffect, useState } from 'react';
import { Post } from '../types';
import { HeartIcon, CommentIcon, ShareIcon, MusicIcon, MoreHorizontalIcon, BookmarkIcon, RepostIcon, OrbIcon, ChevronLeftIcon } from './Icons';

// Helper to format numbers
const formatNumber = (num: number): string => {
  if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
  return num.toString();
};

interface VideoPostProps {
  post: Post;
  isActive: boolean;
  toggleLike: (id: string) => void;
  openComments: (post: Post) => void;
  openShare: (post: Post) => void;
  onAvatarClick: (username: string) => void;
  onGift?: (post: Post) => void;
  autoPlay?: boolean;
}

export const VideoPost: React.FC<VideoPostProps> = ({ post, isActive, toggleLike, openComments, openShare, onAvatarClick, onGift, autoPlay = true }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const [isFollowed, setIsFollowed] = useState(false);
  const lastTapRef = useRef<number>(0);

  useEffect(() => { setIsFollowed(false); }, [post.id]);

  useEffect(() => {
    if (isActive && autoPlay) {
      const timer = setTimeout(() => {
        if (videoRef.current) {
          videoRef.current.currentTime = 0;
          videoRef.current.play().then(() => setIsPlaying(true)).catch(e => console.log("Autoplay prevented", e));
        }
      }, 200);
      return () => clearTimeout(timer);
    } else {
      if (videoRef.current) {
        videoRef.current.pause();
        setIsPlaying(false);
      }
    }
  }, [isActive, autoPlay]);

  const handleVideoClick = (e: React.MouseEvent) => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      toggleLike(post.id);
      setShowHeart(true);
      setTimeout(() => setShowHeart(false), 800);
    } else {
      togglePlay();
    }
    lastTapRef.current = now;
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  return (
    <div className="relative h-full w-full snap-start bg-transparent p-2 pb-24 overflow-hidden select-none">
      {/* "Prism" Card Container */}
      <div className="relative h-full w-full rounded-[30px] overflow-hidden shadow-2xl border border-white/10 bg-black">
          
          {/* Video Layer */}
          <div className="absolute inset-0 cursor-pointer" onClick={handleVideoClick}>
            <video
              ref={videoRef}
              src={post.videoUrl}
              className="h-full w-full object-cover"
              playsInline
              loop
              muted={false} 
            />
            {/* Play Indicator */}
            {!isPlaying && (
               <div className="absolute inset-0 flex items-center justify-center bg-black/20 backdrop-blur-[2px]">
                 <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20">
                    <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[20px] border-l-white border-b-[10px] border-b-transparent ml-1"></div>
                 </div>
               </div>
            )}
            {/* Heart Animation */}
            {showHeart && (
               <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <div className="animate-popup">
                    <HeartIcon filled={true} className="w-32 h-32 text-[#fe2c55] drop-shadow-[0_0_15px_rgba(254,44,85,0.5)]" />
                 </div>
               </div>
            )}
          </div>

          {/* Top Info (Location/Series) */}
          <div className="absolute top-4 left-4 right-4 z-20 flex justify-between pointer-events-none">
              {post.seriesName && (
                  <div className="glass-capsule px-3 py-1 rounded-full flex items-center gap-2">
                      <div className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
                      <span className="text-[10px] font-bold text-white uppercase tracking-wider">{post.seriesName}</span>
                  </div>
              )}
              {post.isRepost && (
                  <div className="glass-capsule px-3 py-1 rounded-full flex items-center gap-1 ml-auto">
                      <RepostIcon className="w-3 h-3 text-white" />
                      <span className="text-[10px] text-white font-bold">Reshared</span>
                  </div>
              )}
          </div>

          {/* Bottom Interface Layer */}
          <div className="absolute bottom-0 left-0 right-0 z-20 p-4 pb-6 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end">
              
              <div className="flex flex-col items-start gap-2 pointer-events-auto">
                  
                  {/* Follow Button (Above Name) */}
                  {!isFollowed && (
                      <button 
                        onClick={(e) => { e.stopPropagation(); setIsFollowed(true); }}
                        className="bg-[#800020] text-white text-[10px] font-bold px-3 py-1 rounded-full mb-1 shadow-md hover:scale-105 transition-transform"
                      >
                        Follow
                      </button>
                  )}

                  {/* Main Row: Avatar | Name | Actions */}
                  <div className="flex items-center gap-3 w-full">
                      <div className="relative cursor-pointer" onClick={(e) => { e.stopPropagation(); onAvatarClick(post.username); }}>
                          <img src={post.avatar} className="w-10 h-10 rounded-full object-cover border-2 border-white/20" />
                      </div>

                      <div className="flex flex-col justify-center gap-1">
                          <div className="flex items-center gap-4">
                              <h3 className="font-bold text-white text-sm shadow-black drop-shadow-md cursor-pointer" onClick={(e) => { e.stopPropagation(); onAvatarClick(post.username); }}>@{post.username}</h3>
                              
                              {/* Inline Actions */}
                              <div className="flex items-center gap-3">
                                  <button onClick={(e) => { e.stopPropagation(); toggleLike(post.id); }} className="flex items-center gap-1 group">
                                      <HeartIcon filled={post.isLiked} className={`w-6 h-6 ${post.isLiked ? 'text-[#fe2c55]' : 'text-white'} drop-shadow-md`} />
                                      <span className="text-[10px] font-bold text-white">{formatNumber(post.likes)}</span>
                                  </button>

                                  <button onClick={(e) => { e.stopPropagation(); openComments(post); }} className="flex items-center gap-1 group">
                                      <CommentIcon className="w-6 h-6 text-white drop-shadow-md" />
                                      <span className="text-[10px] font-bold text-white">{formatNumber(post.comments)}</span>
                                  </button>

                                  <button onClick={(e) => { e.stopPropagation(); openShare(post); }} className="flex items-center gap-1 group">
                                      <ShareIcon className="w-6 h-6 text-white drop-shadow-md" />
                                      <span className="text-[10px] font-bold text-white">{formatNumber(post.shares)}</span>
                                  </button>
                              </div>
                          </div>
                      </div>
                      
                      {/* More Options (Far Right) */}
                      <button className="ml-auto opacity-70 hover:opacity-100">
                          <MoreHorizontalIcon className="w-5 h-5 text-white" />
                      </button>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-white/90 font-medium leading-snug line-clamp-2 drop-shadow-md max-w-[90%] mt-1">{post.description}</p>
                  
                  {/* Audio Pill */}
                  <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/10 mt-1">
                      <MusicIcon className="w-3 h-3 text-yellow-400" />
                      <div className="text-[10px] font-bold text-white max-w-[150px] truncate">{post.music}</div>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

interface FeedProps {
  posts: Post[];
  toggleLike: (id: string) => void;
  openComments: (post: Post) => void;
  openShare: (post: Post) => void;
  onAvatarClick?: (username: string) => void;
  onGift?: (post: Post) => void;
  initialIndex?: number;
  onBack?: () => void;
}

export const Feed: React.FC<FeedProps> = ({ posts, toggleLike, openComments, openShare, onAvatarClick, onGift, initialIndex = 0, onBack }) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(initialIndex);
  
  // Swipe Logic
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  useEffect(() => {
    if (containerRef.current && initialIndex > 0) {
      const el = containerRef.current.children[initialIndex] as HTMLElement;
      if (el) el.scrollIntoView({ behavior: 'auto' });
    }
  }, [initialIndex]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const handleScroll = () => {
      const index = Math.round(container.scrollTop / container.clientHeight);
      if (index !== activeIndex) setActiveIndex(index);
    };
    container.addEventListener('scroll', handleScroll);
    return () => container.removeEventListener('scroll', handleScroll);
  }, [activeIndex]);

  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
    touchStartY.current = e.targetTouches[0].clientY;
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartX.current || !touchStartY.current || !onBack) return;
    
    const touchEndX = e.changedTouches[0].clientX;
    const touchEndY = e.changedTouches[0].clientY;
    
    const deltaX = touchEndX - touchStartX.current;
    const deltaY = touchEndY - touchStartY.current;
    
    // Check for Swipe Right (Left to Right) with minimal vertical movement
    // Threshold: 50px horizontal, vertical movement less than horizontal
    if (deltaX > 60 && Math.abs(deltaX) > Math.abs(deltaY)) {
        onBack();
    }
    
    touchStartX.current = null;
    touchStartY.current = null;
  };

  return (
    <div 
      ref={containerRef}
      className="h-full w-full overflow-y-scroll snap-y snap-mandatory scroll-smooth no-scrollbar pt-2"
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      {onBack && (
          <div className="fixed top-6 left-6 z-50 animate-fade-in">
              <button onClick={onBack} className="bg-black/40 backdrop-blur-md p-2 rounded-full border border-white/20 text-white shadow-lg active:scale-95 transition-transform">
                  <ChevronLeftIcon className="w-6 h-6" />
              </button>
          </div>
      )}

      {posts.map((post, index) => (
        <div key={post.id} className="h-full w-full snap-start">
          <VideoPost 
            post={post} 
            isActive={index === activeIndex}
            toggleLike={toggleLike}
            openComments={openComments}
            openShare={openShare}
            onAvatarClick={(username) => onAvatarClick && onAvatarClick(username)}
            onGift={onGift}
          />
        </div>
      ))}
      <div className="h-24 w-full snap-start flex items-center justify-center text-white/50 text-sm pb-20">
        <div className="flex flex-col items-center gap-2">
           <OrbIcon className="w-6 h-6 animate-spin" />
           <span>Loading Flow...</span>
        </div>
      </div>
    </div>
  );
};
