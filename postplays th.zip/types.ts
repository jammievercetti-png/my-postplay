export interface Comment {
  id: string;
  username: string;
  avatar: string;
  text: string;
  timestamp: string;
  likes: number;
  replies?: Comment[];
  pinned?: boolean;
  videoReplyId?: string; // If this comment is a reply with a video
}

export interface Post {
  id: string;
  type: 'video' | 'image' | 'carousel';
  videoUrl?: string;
  images?: string[]; // For carousels
  username: string;
  description: string;
  music: string;
  likes: number;
  comments: number;
  shares: number;
  avatar: string;
  isLiked?: boolean; // Local state
  category?: 'dance' | 'comedy' | 'pets' | 'nature' | 'food' | 'lifestyle' | 'fitness' | 'sports' | 'business';
  views: number;
  seriesId?: string;
  seriesName?: string;
  isRepost?: boolean;
  repostUsername?: string;
  taggedProducts?: Product[];
  taggedUsers?: string[]; // User IDs
  location?: string;
  reports?: number;
  reaction?: string;
  privacy: 'public' | 'followers' | 'private' | 'close_friends';
  allowDuet?: boolean;
  allowStitch?: boolean;
}

// --- ECHO / NOTE DROP TYPES ---

export interface Story {
  id: string;
  username: string;
  avatar: string;
  mediaUrl: string; // Image or Video
  type: 'image' | 'video';
  duration: number; // seconds
  timestamp: number;
  isSeen?: boolean;
  isCloseFriends?: boolean;
  viewers?: string[];
}

export interface NoteItem {
  // Placeholder for potential future use or refactoring
}

export interface LegacyNote {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  text: string;
  timestamp: number;
  music?: string;
}

export interface Echo {
  id: string;
  creatorId: string;
  username: string;
  handle: string;
  avatar: string;
  content: string;
  timestamp: number;
  visibility: 'public' | 'circles' | 'selected';
  
  boostCount: number;
  echoCount: number;
  replyCount: number;
  
  isBoosted?: boolean;
  
  isEcho?: boolean; // Is this a repost?
  originalEcho?: Echo; // The content being echoed
  
  factCheckStatus?: 'verified' | 'context' | 'unverified' | 'misleading';
}

export interface Note {
  id: string;
  userId: string;
  username: string;
  avatar: string;
  text: string;
  timestamp: number;
  music?: string;
}

export enum AppView {
  AUTH = 'AUTH',
  FEED = 'FEED',
  ECHO_FEED = 'ECHO_FEED', // NEW
  UPLOAD = 'UPLOAD',
  PROFILE = 'PROFILE',
  INBOX = 'INBOX',
  DISCOVER = 'DISCOVER',
  SHOP = 'SHOP',
  LIVE = 'LIVE',
  CREATOR_TOOLS = 'CREATOR_TOOLS',
  SETTINGS = 'SETTINGS',
  OTHER_PROFILE = 'OTHER_PROFILE',
  ADMIN_DASHBOARD = 'ADMIN_DASHBOARD',
  MAP = 'MAP'
}

export type UserRole = 'user' | 'admin' | 'super_admin';

export interface AdminPermissions {
  canManageUsers: boolean;
  canManageContent: boolean;
  canManageAdmins: boolean;
  canViewAnalytics: boolean;
}

export interface UserSettings {
  theme?: 'dark' | 'light' | 'system';
  language?: string;
  twoFactorEnabled?: boolean;
  twoFactorMethod?: 'sms' | 'auth_app';
  activityStatus?: boolean;
}

export interface TeenSettings {
  enabled: boolean;
  privateAccount: boolean;
  dmLimitations: boolean;
  sensitiveContentFilter: 'strict' | 'standard';
  discoverabilityLimited: boolean;
  defaultCommentControls: 'friends_only' | 'everyone';
}

export interface Wallet {
  coins: number; // Purchased currency
  diamonds: number; // Earned currency from gifts
  balance: number; // Cash value estimate
}

export interface CreatorStats {
  views: number;
  reach: number;
  engagement: number;
  watchTime: number;
  monetizationEarned: number;
  retention: number;
  followerGrowth: number;
}

export interface UserProfile {
  id: string;
  username: string;
  handle: string;
  avatar: string;
  email?: string; 
  phoneNumber?: string;
  isPhoneVerified?: boolean;
  
  // Social Graph
  following: string[]; 
  followers: string[]; 
  closeFriends: string[]; 
  blockedUsers?: string[]; 
  
  // Profile Info
  likes: number;
  bio: string;
  pronouns?: string;
  website?: string;
  gender?: string;
  interests?: string[];
  
  // Status
  isBrand?: boolean;
  isVerified?: boolean;
  verificationStatus?: 'none' | 'pending' | 'verified';
  isCreator?: boolean;
  
  // Settings & Config
  privacySettings?: {
    whoCanMessageMe?: 'everyone' | 'friends' | 'no_one';
    accountVisibility?: 'public' | 'private';
    commentsFrom?: 'everyone' | 'friends' | 'no_one';
  };
  settings?: UserSettings; 
  teenMode?: TeenSettings;
  
  // Money
  wallet?: Wallet;

  role: UserRole;
  permissions?: AdminPermissions;
  isBanned?: boolean;
  createdAt: number;
  dateOfBirth?: string;
}

export interface VerificationRequest {
  userId: string;
  fullName: string;
  idDocumentUrl: string;
  category: 'creator' | 'brand';
  status: 'pending' | 'approved' | 'rejected';
  timestamp: number;
}

export interface Report {
  userId: string;
  type: string;
  description: string;
  device?: string;
  os?: string;
  timestamp: number;
}

export interface Place {
  id: string;
  name: string;
  category: string;
  address: string;
  rating: number;
  image: string;
  lat: number; 
  lng: number; 
  reviews: number;
  isOpen?: boolean;
  priceLevel?: string; 
}

export interface Message {
  id: string;
  text: string;
  sender: 'me' | 'them';
  timestamp: number;
  type: 'text' | 'audio' | 'video_call_log' | 'location' | 'media';
  mediaUrl?: string;
  status: 'sent' | 'delivered' | 'read';
  isDeleted?: boolean;
  reaction?: string;
  locationData?: Place; 
}

export interface Chat {
  id: string;
  username: string;
  avatar: string;
  lastMessage: string;
  unread: number;
  timestamp: number;
  messages: Message[];
  isOnline?: boolean;
  userId: string; 
}

export interface Product {
  id: string;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  sales: number;
  rating: number;
  seller: string;
}

export interface AnalyticsData {
  views: number[];
  likes: number[];
  followers: number[];
  dates: string[];
  totalSales?: number;
  revenue?: number;
}

export interface AuthUser extends UserProfile {
  email: string;
  password?: string; 
}

export interface Community {
  id: string;
  name: string;
  coverImage: string;
  members: number;
  description: string;
  isJoined?: boolean;
}

export interface CommunityPost {
  id: string;
  user: string;
  avatar: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  timestamp: number;
}

export interface WeCareResult {
  question: string;
  summary: string;
  sources: { name: string; url: string }[];
}

// --- NEW TYPES FOR LIVE & GIFTING ---

export interface Gift {
  id: string;
  name: string;
  coinValue: number;
  animationUrl: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface LiveSession {
  id: string;
  hostId: string;
  title: string;
  topic: string;
  coverImage: string;
  viewers: number;
  isActive: boolean;
  moderators: string[];
  guests: string[]; // User IDs in multi-guest
  giftsReceived: number;
}

export interface Notification {
  id: string;
  userId: string; // Recipient
  type: 'new_follower' | 'like_received' | 'comment_received' | 'reply_received' | 'tagged_in_post' | 'story_mentioned' | 'live_started' | 'gift_received' | 'message_received' | 'system_announcement';
  fromUser?: string;
  fromAvatar?: string;
  content?: string; // "liked your video", "sent a rose"
  timestamp: number;
  read: boolean;
  linkId?: string; // Link to post/video/live
}