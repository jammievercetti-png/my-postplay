
import React, { useState, useEffect } from 'react';
import { UserProfile, Post, AppView } from '../types';
import { Feed } from '../components/VideoFeed';
import { ChevronLeftIcon, MenuIcon, SettingsIcon, LiveIcon, ChartIcon, BagIcon, LockIcon, UserIcon, HeartIcon } from '../components/Icons';
import { isFollowing, followUser, unfollowUser, getUserById, isCloseFriend, toggleCloseFriend } from '../services/social';

interface ProfileProps {
  user: UserProfile;
  posts: Post[];
  isCurrentUser: boolean;
  onNavigateTo: (view: AppView) => void;
  onLogout: () => void;
  onBack?: () => void;
  setFullScreen: (isFull: boolean) => void;
}

export const Profile: React.FC<ProfileProps> = ({ user, posts, isCurrentUser, onNavigateTo, onLogout, onBack, setFullScreen }) => {
  const [activePostIndex, setActivePostIndex] = useState<number | null>(null);
  const [showDrawer, setShowDrawer] = useState(false);
  const [followed, setFollowed] = useState(false);
  const [closeFriend, setCloseFriend] = useState(false);
  
  // Real-time stats
  const [followerCount, setFollowerCount] = useState(user.followers.length);
  const [followingCount, setFollowingCount] = useState(user.following.length);

  // Sync state on mount and when user prop updates
  useEffect(() => {
    setFollowerCount(user.followers.length);
    setFollowingCount(user.following.length);

    if (!isCurrentUser) {
      setFollowed(isFollowing(user.id));
      setCloseFriend(isCloseFriend(user.id));
    }
  }, [user, isCurrentUser]);

  const handleFollowToggle = () => {
    if (followed) {
      unfollowUser(user.id);
      setFollowerCount(prev => Math.max(0, prev - 1));
    } else {
      followUser(user.id);
      setFollowerCount(prev => prev + 1);
    }
    setFollowed(!followed);
  };
  
  const handleCloseFriendToggle = () => {
    toggleCloseFriend(user.id);
    setCloseFriend(!closeFriend);
  };

  const handlePostClick = (index: number) => {
    setActivePostIndex(index);
    setFullScreen(true);
  };

  const closeFullScreen = () => {
    setActivePostIndex(null);
    setFullScreen(false);
  };

  return (
    <div className="h-full w-full bg-white relative text-gray-900">
      
      {/* 1. Main Profile Scroll View */}
      <div className="h-full overflow-y-auto no-scrollbar bg-white">
        
        {/* Top Actions */}
        <div className="sticky top-0 z-20 flex justify-between px-4 py-3 bg-white/90 backdrop-blur-sm">
           {isCurrentUser ? (
             <div className="w-8"></div> // Spacer
           ) : (
             <button onClick={onBack}><ChevronLeftIcon className="w-6 h-6 text-black" /></button>
           )}
           
           <div className="font-bold text-base truncate max-w-[150px] text-black">{user.username} {user.isVerified && '☑️'}</div>
           
           {isCurrentUser ? (
             <button onClick={() => onNavigateTo(AppView.SETTINGS)}>
                <MenuIcon className="w-6 h-6 text-black" />
             </button>
           ) : (
             <button onClick={() => setShowDrawer(true)}>
                <div className="rotate-90 font-bold text-lg text-black">...</div>
             </button>
           )}
        </div>

        {/* Profile Stats */}
        <div className="flex flex-col items-center pt-4 pb-6 border-b border-gray-50">
          <div className="relative">
             <div className="w-24 h-24 rounded-full overflow-hidden border border-gray-200 shadow-sm p-1">
               <img src={user.avatar} className="w-full h-full object-cover rounded-full" />
             </div>
          </div>
          <h1 className="mt-3 font-bold text-lg text-black">@{user.handle}</h1>
          
          <div className="flex items-center gap-12 mt-4 text-center">
             <div className="cursor-pointer"><div className="font-bold text-lg text-black">{followingCount}</div><div className="text-xs text-gray-500">Following</div></div>
             <div className="cursor-pointer"><div className="font-bold text-lg text-black">{followerCount}</div><div className="text-xs text-gray-500">Followers</div></div>
             <div className="cursor-pointer"><div className="font-bold text-lg text-black">{user.likes}</div><div className="text-xs text-gray-500">Likes</div></div>
          </div>

          <div className="flex gap-2 mt-6 px-4">
             {isCurrentUser ? (
               <>
                 <button className="px-8 py-2.5 bg-gray-100 text-black rounded-sm font-semibold text-sm border border-gray-200">Edit Profile</button>
                 <button className="px-3 py-2.5 bg-gray-100 text-black rounded-sm border border-gray-200" onClick={() => onNavigateTo(AppView.CREATOR_TOOLS)}>
                    <ChartIcon className="w-5 h-5" />
                 </button>
               </>
             ) : (
               <>
                 <button 
                   onClick={handleFollowToggle}
                   className={`px-12 py-2.5 rounded-sm font-semibold text-sm transition-colors ${followed ? 'bg-gray-100 text-black border border-gray-200' : 'bg-[#800020] hover:bg-[#600018] text-white'}`}
                 >
                   {followed ? 'Following' : 'Follow'}
                 </button>
                 {followed && (
                    <button onClick={handleCloseFriendToggle} className={`px-3 py-2.5 rounded-sm border ${closeFriend ? 'bg-green-100 border-green-200 text-green-700' : 'bg-gray-100 border-gray-200'}`}>
                      {closeFriend ? 'CF' : '☆'}
                    </button>
                 )}
                 <button className="px-3 py-2.5 bg-gray-100 text-black rounded-sm border border-gray-200">
                    <div className="rotate-90">▼</div>
                 </button>
               </>
             )}
          </div>

          <p className="mt-4 text-center px-8 text-sm text-gray-800 leading-relaxed whitespace-pre-line">{user.bio}</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-gray-200 sticky top-[52px] bg-white z-10 shadow-sm">
            <div className="flex-1 py-3 flex justify-center border-b-2 border-black cursor-pointer">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="black" strokeWidth="2"><line x1="21" y1="10" x2="3" y2="10"></line><line x1="21" y1="6" x2="3" y2="6"></line><line x1="21" y1="14" x2="3" y2="14"></line><line x1="21" y1="18" x2="3" y2="18"></line></svg>
            </div>
            <div className="flex-1 py-3 flex justify-center text-gray-400 cursor-pointer hover:bg-gray-50">
                <LockIcon className="w-5 h-5" />
            </div>
            <div className="flex-1 py-3 flex justify-center text-gray-400 cursor-pointer hover:bg-gray-50">
                <HeartIcon className="w-5 h-5" />
            </div>
        </div>

        {/* Masonry Grid */}
        <div className="p-0.5 pb-24 bg-white min-h-[300px]">
           <div className="columns-3 gap-0.5 space-y-0.5">
              {posts.map((post, index) => (
                <div key={post.id} className="relative break-inside-avoid cursor-pointer" onClick={() => handlePostClick(index)}>
                   {/* Aspect Ratio Hack using padding or just explicit rendering based on content */}
                   <div className="relative w-full overflow-hidden bg-gray-100">
                      {/* Using video tag for thumbnail since we don't have separate thumbs in mock */}
                      <video src={post.videoUrl} className="w-full h-auto object-cover" muted />
                      <div className="absolute bottom-1 left-1 flex items-center gap-1 text-white drop-shadow-md">
                         <svg width="10" height="10" viewBox="0 0 24 24" fill="white"><path d="M20.84 4.61a5.5 5.5 0 00-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 00-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 000-7.78z"></path></svg>
                         <span className="text-[9px] font-bold">{post.likes}</span>
                      </div>
                   </div>
                </div>
              ))}
              {posts.length === 0 && (
                <div className="col-span-3 text-center py-10 text-gray-400 text-sm">No posts yet</div>
              )}
           </div>
        </div>
      </div>

      {/* 2. Full Screen Feed View (when post clicked) */}
      {activePostIndex !== null && (
        <div className="fixed inset-0 z-50 bg-black animate-in fade-in zoom-in-95 duration-200">
           <Feed 
             posts={posts} 
             initialIndex={activePostIndex}
             toggleLike={(id) => {/* In real app, sync back to parent state */}}
             openComments={(p) => {/* Handle via App context or prop */}}
             openShare={(p) => {/* Handle via App context or prop */}}
             onAvatarClick={() => {}}
             onGift={() => {}}
             onBack={closeFullScreen}
           />
        </div>
      )}

      {/* Other User Menu Drawer */}
      {showDrawer && !isCurrentUser && (
        <div className="absolute inset-0 z-50">
           <div className="absolute inset-0 bg-black/50" onClick={() => setShowDrawer(false)}></div>
           <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-xl animate-slide-up pb-8">
              <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mt-3 mb-6"></div>
              <button className="w-full py-3 text-red-600 font-bold border-b border-gray-100" onClick={() => { alert('Blocked'); setShowDrawer(false); }}>Block</button>
              <button className="w-full py-3 text-gray-700 font-medium" onClick={() => { alert('Reported'); setShowDrawer(false); }}>Report</button>
              <button className="w-full py-3 text-gray-500" onClick={() => setShowDrawer(false)}>Cancel</button>
           </div>
        </div>
      )}
    </div>
  );
};
