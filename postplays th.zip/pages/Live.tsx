
import React, { useState, useEffect } from 'react';
import { LiveSession } from '../types';
import { ShareIcon, UserIcon, SwordsIcon, GiftIcon, XIcon, OrbIcon } from '../components/Icons';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../services/firebase';

interface LiveProps {
    onBack?: () => void;
}

export const Live: React.FC<LiveProps> = ({ onBack }) => {
  const [lives, setLives] = useState<LiveSession[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
      const fetchLives = async () => {
          try {
              const q = query(collection(db, 'lives'), where('isActive', '==', true));
              const snap = await getDocs(q);
              const data = snap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as LiveSession));
              setLives(data);
          } catch (e) {
              console.error(e);
          } finally {
              setLoading(false);
          }
      };
      fetchLives();
  }, []);

  const handleBattleRequest = () => {
    console.log('Requesting Live Battle...');
  };

  return (
    <div className="h-full w-full bg-black snap-y snap-mandatory overflow-y-scroll no-scrollbar relative">
      
      {onBack && (
          <div className="fixed top-6 right-4 z-50 animate-fade-in">
              <button 
                onClick={onBack}
                className="glass-capsule w-10 h-10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors shadow-lg border border-white/20"
              >
                  <XIcon className="w-5 h-5 drop-shadow-md" />
              </button>
          </div>
      )}

      {loading ? (
          <div className="h-full w-full flex items-center justify-center flex-col text-white/50">
              <OrbIcon className="w-10 h-10 animate-spin mb-4" />
              <p>Tuning in...</p>
          </div>
      ) : lives.length === 0 ? (
          <div className="h-full w-full flex items-center justify-center flex-col text-white">
              <h2 className="text-xl font-bold mb-2">No one is Live right now</h2>
              <p className="text-white/60 mb-6">Be the first to go Live!</p>
              <button onClick={onBack} className="bg-[#800020] px-6 py-3 rounded-full font-bold">Go Back</button>
          </div>
      ) : (
          lives.map((live) => (
            <div key={live.id} className="h-full w-full snap-start relative bg-gray-900 overflow-hidden">
               {/* Background Video Simulation */}
               <img src={live.coverImage || 'https://picsum.photos/seed/live/400/800'} className="absolute inset-0 w-full h-full object-cover opacity-60" />
               <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/90"></div>

               {/* Top Info Bar */}
               <div className="absolute top-24 left-4 right-16 flex items-center justify-between z-20 pointer-events-none">
                  <div className="bg-black/30 backdrop-blur-md rounded-full p-1 pr-4 flex items-center gap-2 border border-white/10 pointer-events-auto">
                     <div className="flex flex-col">
                        <div className="font-bold text-white text-xs leading-tight">Host ID: {live.hostId.slice(0,5)}</div>
                        <div className="text-[9px] text-gray-300 flex items-center gap-1">
                            <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div> {live.viewers.toLocaleString()}
                        </div>
                     </div>
                     <button className="bg-[#800020] hover:bg-[#600018] text-white text-[10px] font-bold px-3 py-1 rounded-full ml-2">Follow</button>
                  </div>
               </div>

               {/* Center Right: Battle Button */}
               <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex flex-col gap-4 z-20 items-center pointer-events-auto">
                   <button 
                     onClick={handleBattleRequest}
                     className="flex flex-col items-center gap-1 group"
                   >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center border-2 border-white/20 shadow-lg animate-pulse group-active:scale-95 transition-transform">
                         <SwordsIcon className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-[9px] font-bold text-white bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm">PK</span>
                   </button>
               </div>

               {/* Bottom Actions Row */}
               <div className="absolute bottom-6 left-0 right-0 px-4 flex items-center gap-3 z-30 pointer-events-auto">
                  <div className="flex-1 bg-black/40 backdrop-blur-md rounded-full h-10 px-4 flex items-center text-gray-400 text-sm border border-white/10 cursor-text hover:bg-black/60 transition-colors">
                     Say something...
                  </div>
                  
                  <button className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white border border-white/10 active:bg-gray-800 transition-colors">
                     <UserIcon className="w-5 h-5" />
                  </button>
                  
                  <button className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white border border-white/10 active:bg-gray-800 transition-colors">
                     <ShareIcon className="w-5 h-5" />
                  </button>
                  
                  <button className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#800020] to-red-600 flex items-center justify-center text-white shadow-lg active:scale-95 transition-transform border border-white/20">
                     <GiftIcon className="w-5 h-5" />
                  </button>
               </div>
            </div>
          ))
      )}
    </div>
  );
};
