import { UserProfile, Post, Community, WeCareResult } from '../types';
import { db, isFirebaseConfigured } from './firebase';
import { collection, query, where, getDocs, doc, getDoc, updateDoc, arrayUnion, arrayRemove, orderBy, limit, addDoc } from "firebase/firestore";
import { getCurrentUser } from './auth';

const POSTS_COLLECTION = 'posts';
const USERS_COLLECTION = 'users';

export const getFeedPosts = async (): Promise<Post[]> => {
    if (!isFirebaseConfigured()) return [];
    try {
        const q = query(collection(db, POSTS_COLLECTION), orderBy('createdAt', 'desc'), limit(20));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Post));
    } catch (e) {
        console.warn("Feed fetch error:", e);
        return [];
    }
};

export const createPost = async (description: string, videoUrl: string, user: UserProfile) => {
    if (!isFirebaseConfigured()) return;
    const newPost: any = {
      type: 'video',
      videoUrl: videoUrl,
      username: user.username,
      description: description,
      music: 'Original Sound',
      likes: 0,
      comments: 0,
      shares: 0,
      avatar: user.avatar,
      isLiked: false,
      views: 0,
      createdAt: Date.now(),
      userId: user.id,
      privacy: 'public'
    };
    await addDoc(collection(db, POSTS_COLLECTION), newPost);
};

export const getUserById = async (id: string): Promise<UserProfile | null> => {
    if (!isFirebaseConfigured()) return null;
    try {
        const docRef = doc(db, USERS_COLLECTION, id);
        const snap = await getDoc(docRef);
        return snap.exists() ? (snap.data() as UserProfile) : null;
    } catch (e) {
        return null;
    }
};

export const getUserByHandle = async (handle: string): Promise<UserProfile | null> => {
    if (!isFirebaseConfigured()) return null;
    const q = query(collection(db, USERS_COLLECTION), where("handle", "==", handle), limit(1));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs[0].data() as UserProfile;
    return null;
};

// Legacy Wrappers using the new Command structure where possible
import { cmd } from './commands';

export const followUser = async (targetUserId: string) => {
    await cmd.user.follow(targetUserId);
};

export const unfollowUser = async (targetUserId: string) => {
    await cmd.user.unfollow(targetUserId);
};

export const blockUser = async (targetUserId: string) => {
    await cmd.user.block(targetUserId);
};

export const toggleCloseFriend = async (targetUserId: string) => {
    const user = getCurrentUser();
    if (!user) return;
    if (user.closeFriends.includes(targetUserId)) {
        await cmd.user.close_friends.remove(targetUserId);
    } else {
        await cmd.user.close_friends.add(targetUserId);
    }
};

export const isBlocked = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.blockedUsers?.includes(targetUserId) || false;
};

export const isFollowing = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.following.includes(targetUserId) || false;
};

export const isCloseFriend = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.closeFriends.includes(targetUserId) || false;
};

export const getFollowingFeed = async (allPosts: Post[]): Promise<Post[]> => {
    return cmd.feed.following(); 
};

export const getCommunities = async (): Promise<Community[]> => {
    try {
        const snap = await getDocs(collection(db, 'communities'));
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as Community));
    } catch (e) { return []; }
};

export const searchWeCare = async (query: string): Promise<WeCareResult> => {
    // In production, this calls an API or Algolia
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                question: query,
                summary: "This is a verified result from the We Care database.",
                sources: [{ name: 'WHO', url: 'https://who.int' }]
            });
        }, 1000);
    });
};