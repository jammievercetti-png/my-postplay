
import React, { useState, useEffect } from 'react';
import { Feed } from './components/VideoFeed';
import { BottomNav, TopNavFeed } from './components/Navigation';
import { Upload } from './pages/Upload';
import { Profile } from './pages/Profile';
import { Inbox } from './pages/Inbox';
import { Shop } from './pages/Shop';
import { Live } from './pages/Live';
import { Discover } from './pages/Discover';
import { CreatorHub } from './pages/CreatorHub';
import { Auth } from './pages/Auth';
import { Settings } from './pages/Settings';
import { AdminDashboard } from './pages/AdminDashboard';
import { MapExplorer } from './pages/MapExplorer';
import { EchoFeed } from './pages/EchoFeed'; 
import { AppView, Post, UserProfile, AuthUser, Story } from './types';
import { logout, initAuthListener } from './services/auth';
import { getFeedPosts, createPost, getUserByHandle, getFollowingFeed } from './services/social';
import { StoriesRail } from './components/StoriesRail';
import { ShareSheet } from './components/ShareSheet';
import { StoryViewer } from './components/StoryViewer';
import { CheckIcon, OrbIcon } from './components/Icons';
import { storage } from './services/firebase';
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { cmd } from './services/commands';

export default function App() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [currentView, setCurrentView] = useState<AppView>(AppView.FEED);
  const [feedTab, setFeedTab] = useState<'live' | 'following' | 'foryou'>('foryou');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loadingPosts, setLoadingPosts] = useState(true);
  const [isAuthChecking, setIsAuthChecking] = useState(true);
  
  // Real Data State
  const [stories, setStories] = useState<Story[]>([]);
  const [liveUsers, setLiveUsers] = useState<UserProfile[]>([]);
  
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [commentsOpen, setCommentsOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [storyOpen, setStoryOpen] = useState(false);
  const [activeStoryIndex, setActiveStoryIndex] = useState(0);
  
  const [activePost, setActivePost] = useState<Post | null>(null);
  const [otherUserProfile, setOtherUserProfile] = useState<UserProfile | null>(null);
  const [showStoriesOnFeed, setShowStoriesOnFeed] = useState(true);
  const [showToast, setShowToast] = useState<{message: string, visible: boolean}>({ message: '', visible: false });

  useEffect(() => {
    const unsubscribe = initAuthListener((u) => {
        setIsAuthChecking(false);
        if (u) {
            if (u.isBanned) { 
                logout(); 
                setUser(null); 
                setCurrentView(AppView.AUTH); 
                triggerToast("Account banned"); 
            } else { 
                setUser(u); 
                if (currentView === AppView.AUTH) setCurrentView(AppView.FEED); 
            }
        } else {
            setUser(null);
            setCurrentView(AppView.AUTH);
        }
    });
    return () => unsubscribe && unsubscribe();
  }, []);

  useEffect(() => {
    if (!user) return;
    const loadData = async () => {
        setLoadingPosts(true);
        // Load Feed
        const feed = await getFeedPosts();
        setPosts(feed);
        setLoadingPosts(false);

        // Load Stories (Echoes with images/videos or specific story collection)
        // For production, this would fetch from a 'stories' collection
        // Simulating empty for now until stories are uploaded
        setStories([]); 
        
        // Load Live Users
        // Simulating empty until 'lives' collection has active documents
        setLiveUsers([]);
    };
    loadData();
  }, [user]);

  useEffect(() => {
    if (currentView !== AppView.FEED) return;
    const fetchTabContent = async () => {
        setLoadingPosts(true);
        let res: Post[] = [];
        if (feedTab === 'following') res = await cmd.feed.following();
        else if (feedTab === 'foryou') res = await cmd.feed.for_you();
        // 'live' tab is handled by rendering the Live component directly
        
        if (feedTab !== 'live') {
            setPosts(res);
            setLoadingPosts(false);
        }
    };
    fetchTabContent();
  }, [feedTab, currentView]);

  const triggerToast = (msg: string) => {
      setShowToast({ message: msg, visible: true });
      setTimeout(() => setShowToast({ message: '', visible: false }), 2000);
  };

  const handleLoginSuccess = (authUser: AuthUser) => {
    if (authUser.isBanned) { triggerToast("Account banned"); return; }
    setUser(authUser);
    setCurrentView(AppView.FEED);
  };

  const handleLogout = async () => {
    await logout();
    setUser(null);
    setCurrentView(AppView.AUTH);
  };

  const handlePost = async (description: string, localVideoUrl: string) => {
    if (!user) return;
    triggerToast("Uploading to Flow...");
    try {
      const response = await fetch(localVideoUrl);
      const blob = await response.blob();
      const filename = `videos/${user.id}/${Date.now()}.mp4`;
      const storageRef = ref(storage, filename);
      await uploadBytes(storageRef, blob);
      const publicUrl = await getDownloadURL(storageRef);
      await createPost(description, publicUrl, user);
      
      const updatedFeed = await getFeedPosts();
      setPosts(updatedFeed);
      setCurrentView(AppView.FEED);
      triggerToast("Published to Flow!");
    } catch (e) {
      console.error("Upload failed:", e);
      triggerToast("Upload failed.");
    }
  };

  const navigateToUserProfile = async (username: string) => {
    if (username === user?.username) setCurrentView(AppView.PROFILE);
    else {
      const profile = await getUserByHandle(username);
      if (profile) { setOtherUserProfile(profile); setCurrentView(AppView.OTHER_PROFILE); }
    }
  };

  const myProfile: UserProfile = user ? { ...user } : { id: '', username: '', handle: '', avatar: '', following: [], followers: [], closeFriends: [], likes: 0, bio: '', role: 'user', createdAt: 0 };

  if (isAuthChecking) {
      return (
          <div className="h-[100dvh] w-full bg-black flex items-center justify-center">
              <div className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center animate-pulse">
                      <span className="font-black text-2xl text-black">PP</span>
                  </div>
                  <OrbIcon className="w-8 h-8 text-white animate-spin" />
              </div>
          </div>
      );
  }

  const renderContent = () => {
    if (!user && currentView !== AppView.AUTH) return null;

    switch(currentView) {
      case AppView.AUTH: return <Auth onLoginSuccess={handleLoginSuccess} />;
      case AppView.ADMIN_DASHBOARD: return user ? <AdminDashboard currentUser={user} onBack={() => setCurrentView(AppView.SETTINGS)} /> : null;
      case AppView.UPLOAD: return <Upload onCancel={() => setCurrentView(AppView.FEED)} onPost={handlePost} />;
      case AppView.SHOP: return <Shop />;
      case AppView.LIVE: return <Live onBack={() => { setCurrentView(AppView.FEED); setFeedTab('foryou'); }} />;
      case AppView.MAP: return <MapExplorer onBack={() => setCurrentView(AppView.DISCOVER)} />;
      case AppView.DISCOVER: return <Discover onNavigateToMap={() => setCurrentView(AppView.MAP)} setFullScreen={setIsFullScreen} />;
      case AppView.CREATOR_TOOLS: return <CreatorHub onBack={() => setCurrentView(AppView.PROFILE)} />;
      case AppView.SETTINGS: return <Settings onBack={() => setCurrentView(AppView.PROFILE)} onLogout={handleLogout} onNavigateToAdmin={() => setCurrentView(AppView.ADMIN_DASHBOARD)} />;
      case AppView.PROFILE: return <Profile user={myProfile} isCurrentUser={true} posts={posts.filter(p => p.username === user?.username)} onNavigateTo={(view) => setCurrentView(view)} onLogout={handleLogout} setFullScreen={setIsFullScreen} />;
      case AppView.OTHER_PROFILE: return otherUserProfile ? <Profile user={otherUserProfile} isCurrentUser={false} posts={posts.filter(p => p.username === otherUserProfile.username)} onNavigateTo={(view) => setCurrentView(view)} onLogout={() => {}} onBack={() => setCurrentView(AppView.FEED)} setFullScreen={setIsFullScreen} /> : null;
      case AppView.INBOX: return <Inbox />;
      case AppView.ECHO_FEED: return <EchoFeed onBack={() => setCurrentView(AppView.FEED)} />;
      case AppView.FEED:
      default:
        return (
          <div className="relative h-full w-full">
            <TopNavFeed 
              currentView={currentView} 
              onChangeView={(v) => setCurrentView(v)} 
              feedTab={feedTab}
              setFeedTab={setFeedTab}
            />
            
            {feedTab === 'live' ? (
                <div className="h-full w-full bg-black"><Live onBack={() => setFeedTab('foryou')} /></div>
            ) : (
                <>
                    <div className={`absolute top-20 left-0 right-0 z-30 transition-all duration-500 ease-in-out ${showStoriesOnFeed ? 'translate-y-0 opacity-100' : '-translate-y-20 opacity-0 pointer-events-none'}`}>
                       <StoriesRail 
                           stories={stories} 
                           liveUsers={liveUsers} 
                           className="bg-transparent"
                           onStoryClick={(idx) => { setActiveStoryIndex(idx); setStoryOpen(true); }}
                           onLiveClick={(uid) => { setFeedTab('live'); }} 
                       />
                    </div>

                    {loadingPosts ? (
                        <div className="h-full w-full flex items-center justify-center">
                            <div className="w-8 h-8 border-2 border-white/50 border-t-white rounded-full animate-spin"></div>
                        </div>
                    ) : posts.length === 0 ? (
                        <div className="h-full w-full flex flex-col items-center justify-center text-white/50 pb-20">
                            <OrbIcon className="w-12 h-12 mb-4 opacity-50" />
                            <p>No flows yet.</p>
                            <button onClick={() => setCurrentView(AppView.UPLOAD)} className="mt-4 text-[#800020] font-bold text-sm">Create the first one</button>
                        </div>
                    ) : (
                        <Feed 
                          posts={posts} 
                          toggleLike={(id) => setPosts(p => p.map(x => x.id === id ? {...x, isLiked: !x.isLiked, likes: x.isLiked ? x.likes-1 : x.likes+1} : x))} 
                          openComments={(p) => { setActivePost(p); setCommentsOpen(true); }}
                          openShare={(p) => { setActivePost(p); setShareOpen(true); }}
                          onAvatarClick={navigateToUserProfile}
                          onGift={(p) => triggerToast("Sending gift...")}
                        />
                    )}
                </>
            )}
          </div>
        );
    }
  };

  return (
    <div className={`relative h-[100dvh] w-full max-w-md mx-auto overflow-hidden shadow-2xl ${currentView === AppView.FEED || currentView === AppView.LIVE || currentView === AppView.ECHO_FEED || isFullScreen ? 'bg-black dark-mode' : 'bg-white'}`}>
      {renderContent()}
      
      {showToast.visible && (
          <div className="absolute top-24 left-1/2 transform -translate-x-1/2 glass-capsule text-white px-6 py-2 rounded-full z-[100] animate-slide-up text-sm font-bold shadow-lg flex items-center gap-2">
              <CheckIcon className="w-4 h-4 text-green-400" />
              {showToast.message}
          </div>
      )}

      {user && !isFullScreen && currentView !== AppView.UPLOAD && currentView !== AppView.MAP && currentView !== AppView.LIVE && feedTab !== 'live' && (
         <BottomNav currentView={currentView} onChangeView={(v) => { setCurrentView(v); if(v===AppView.FEED) setShowStoriesOnFeed(true); }} />
      )}

      {commentsOpen && (
        <div className="absolute inset-0 z-50 flex flex-col justify-end">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-opacity" onClick={() => setCommentsOpen(false)}></div>
          <div className="glass-panel border-t border-white/10 bg-[#1a1a20] rounded-t-[30px] h-[70%] w-full relative z-10 animate-slide-up flex flex-col">
             <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div className="w-6"></div>
                <h3 className="font-bold text-sm text-white tracking-wide">COMMENTS ({activePost?.comments || 0})</h3>
                <button onClick={() => setCommentsOpen(false)} className="text-white/50 hover:text-white">✕</button>
             </div>
             <div className="flex-1 flex flex-col items-center justify-center text-white/30 gap-2">
                <p className="text-sm font-medium">No comments yet.</p>
             </div>
          </div>
        </div>
      )}

      {shareOpen && <ShareSheet onClose={() => setShareOpen(false)} onAction={(a) => triggerToast(`Action: ${a}`)} />}
      {storyOpen && stories.length > 0 && <StoryViewer stories={stories} initialIndex={activeStoryIndex} onClose={() => setStoryOpen(false)} />}
    </div>
  );
}
