
import { db, auth } from './firebase';
import { 
    doc, getDoc, updateDoc, setDoc, addDoc, collection, 
    query, where, getDocs, arrayUnion, arrayRemove, deleteDoc,
    increment, orderBy, limit
} from "firebase/firestore";
import { 
    UserProfile, TeenSettings, Post, LiveSession, Gift, 
    Wallet, CreatorStats, Notification, Echo, Product 
} from '../types';

// Helper to get current user ID or throw
const getUid = () => {
    const uid = auth.currentUser?.uid;
    if (!uid) throw new Error("Not authenticated");
    return uid;
};

// ===========================================================
// 0. ANALYTICS & ALGORITHM (THE BRAIN)
// ===========================================================
const analytics = {
    // Aggressively track every action to build a user profile
    track: async (action: 'view' | 'like' | 'share' | 'boost', tags: string[] = [], category?: string) => {
        const uid = auth.currentUser?.uid;
        if (!uid) return; // Silent fail if not logged in

        const userRef = doc(db, 'users', uid);
        
        // Update interest weights
        // In a real production app, this would send data to a separate Analytics DB (BigQuery/Mixpanel)
        // For this architecture, we store a lightweight interest map on the user profile
        try {
            const updates: any = {};
            if (category) {
                // Increment category interest score
                updates[`interests.${category}`] = increment(action === 'like' || action === 'boost' ? 5 : 1);
            }
            // Add unique tags to interest array
            if (tags.length > 0) {
                updates['interestTags'] = arrayUnion(...tags);
            }
            
            await updateDoc(userRef, updates);
        } catch (e) {
            // Fail silently to not disrupt UX
        }
    }
};

// ===========================================================
// 1. TEEN ACCOUNT SYSTEM
// ===========================================================
const teen = {
    mode: {
        evaluate: (dateOfBirth: string): boolean => {
            const birthDate = new Date(dateOfBirth);
            const today = new Date();
            let age = today.getFullYear() - birthDate.getFullYear();
            const m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                age--;
            }
            return age >= 13 && age < 18;
        },
        
        enable: async (userId: string) => {
            const settings: TeenSettings = {
                enabled: true,
                privateAccount: true,
                dmLimitations: true,
                sensitiveContentFilter: 'strict',
                discoverabilityLimited: true,
                defaultCommentControls: 'friends_only'
            };
            await updateDoc(doc(db, 'users', userId), { 
                teenMode: settings,
                'privacySettings.accountVisibility': 'private'
            });
        },

        disable: async (userId: string) => {
            await updateDoc(doc(db, 'users', userId), { teenMode: null });
        },

        restrictions: async (userId: string): Promise<TeenSettings | null> => {
            const snap = await getDoc(doc(db, 'users', userId));
            return (snap.data() as UserProfile)?.teenMode || null;
        }
    }
};

// ===========================================================
// 2. USER SYSTEM
// ===========================================================
const user = {
    profile: {
        update: async (data: Partial<UserProfile>) => {
            const uid = getUid();
            await updateDoc(doc(db, 'users', uid), data);
        }
    },
    
    follow: async (targetId: string) => {
        const uid = getUid();
        
        const currentUserRef = doc(db, 'users', uid);
        const targetUserRef = doc(db, 'users', targetId);

        try {
            await updateDoc(currentUserRef, { following: arrayUnion(targetId) });
            await updateDoc(targetUserRef, { followers: arrayUnion(uid) });
            await notification.send({ type: 'new_follower', userId: targetId, fromUser: uid });
            // Track for algorithm
            await analytics.track('like', [], 'user_interaction');
        } catch (e) {
            console.warn("Follow partial fail:", e);
        }
    },

    unfollow: async (targetId: string) => {
        const uid = getUid();
        try {
            await updateDoc(doc(db, 'users', uid), { following: arrayRemove(targetId) });
            await updateDoc(doc(db, 'users', targetId), { followers: arrayRemove(uid) });
        } catch (e) {
            console.warn("Unfollow partial fail:", e);
        }
    },

    block: async (targetId: string) => {
        const uid = getUid();
        await updateDoc(doc(db, 'users', uid), { 
            blockedUsers: arrayUnion(targetId),
            following: arrayRemove(targetId) 
        });
        try {
            await updateDoc(doc(db, 'users', targetId), { 
                following: arrayRemove(uid),
                followers: arrayRemove(uid)
            });
        } catch (e) {}
    },

    close_friends: {
        add: async (targetId: string) => {
            await updateDoc(doc(db, 'users', getUid()), { closeFriends: arrayUnion(targetId) });
        },
        remove: async (targetId: string) => {
            await updateDoc(doc(db, 'users', getUid()), { closeFriends: arrayRemove(targetId) });
        }
    }
};

// ===========================================================
// 3. POST & VIDEO SYSTEM (RENAMED FROM SNAP)
// ===========================================================
const video = {
    upload: async (args: { fileUrl: string, caption: string, hashtags: string[], cover: string, category?: string }) => {
        const uid = getUid();
        const newPost: Partial<Post> = {
            type: 'video',
            videoUrl: args.fileUrl,
            username: auth.currentUser?.displayName || 'user',
            avatar: auth.currentUser?.photoURL || '',
            description: args.caption,
            likes: 0,
            comments: 0,
            shares: 0,
            views: 0,
            privacy: 'public',
            allowDuet: true,
            allowStitch: true,
            category: args.category as any || 'lifestyle'
        };
        await addDoc(collection(db, 'posts'), { ...newPost, userId: uid, createdAt: Date.now() });
    },

    watch: {
        register: async (videoId: string, category?: string) => {
            try {
                await updateDoc(doc(db, 'posts', videoId), { views: increment(1) });
                await analytics.track('view', [], category);
            } catch (e: any) {
                if (e.code !== 'not-found') throw e;
            }
        }
    }
};

// ===========================================================
// 4. FEED SYSTEM (ALGORITHMIC)
// ===========================================================
const feed = {
    for_you: async (): Promise<Post[]> => {
        const uid = auth.currentUser?.uid;
        
        let preferredCategory = null;
        if (uid) {
            // 1. Get user profile to check interests
            const userSnap = await getDoc(doc(db, 'users', uid));
            const data = userSnap.data() as any;
            const interests = data?.interests || {};
            // Find highest interest
            preferredCategory = Object.keys(interests).reduce((a, b) => interests[a] > interests[b] ? a : b, null);
        }

        let q;
        if (preferredCategory) {
            // 2. Fetch based on interest (Aggressive Algorithm)
            q = query(collection(db, 'posts'), where('category', '==', preferredCategory), orderBy('createdAt', 'desc'), limit(20));
        } else {
            // 3. Fallback to general latest
            q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(20));
        }

        const snap = await getDocs(q);
        const posts = snap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as Post));
        
        // If interest query returned too few, fill with general
        if (posts.length < 5) {
             const generalQ = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(20));
             const generalSnap = await getDocs(generalQ);
             const generalPosts = generalSnap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as Post));
             // Deduplicate
             return [...posts, ...generalPosts.filter(gp => !posts.find(p => p.id === gp.id))];
        }

        return posts;
    },

    following: async (): Promise<Post[]> => {
        const uid = getUid();
        const userSnap = await getDoc(doc(db, 'users', uid));
        const following = (userSnap.data() as UserProfile)?.following || [];
        if (following.length === 0) return [];
        
        const q = query(collection(db, 'posts'), where('userId', 'in', following.slice(0, 10)), limit(20));
        const snap = await getDocs(q);
        return snap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as Post));
    },

    nearby: async (): Promise<Post[]> => {
        const q = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(30));
        const snap = await getDocs(q);
        const posts = snap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as Post));
        return posts.map(p => ({ ...p, location: p.location || `${(Math.random() * 5).toFixed(1)} mi away` }));
    }
};

// ===========================================================
// 5. COMMERCE & BRANDS
// ===========================================================
const product = {
    upload: async (prod: { name: string, price: number, image: string, category: string }) => {
        const uid = getUid();
        const userSnap = await getDoc(doc(db, 'users', uid));
        if (!(userSnap.data() as UserProfile)?.isBrand) throw new Error("Only brands can upload products");

        const newProduct: Partial<Product> = {
            ...prod,
            seller: auth.currentUser?.displayName || 'Brand',
            rating: 5.0,
            sales: 0
        };
        await addDoc(collection(db, 'products'), newProduct);
    }
};

// ===========================================================
// 6. CREATOR PROGRAM
// ===========================================================
const creator = {
    join: async () => {
        const uid = getUid();
        await updateDoc(doc(db, 'users', uid), { isCreator: true });
        return { success: true };
    },
    
    switchToBrand: async () => {
        const uid = getUid();
        await updateDoc(doc(db, 'users', uid), { isBrand: true, isCreator: false }); // Mutual exclusive usually
        return { success: true };
    },

    analytics: async (): Promise<CreatorStats> => {
        // In prod, calculate from subcollections
        return {
            views: 12543,
            reach: 8500,
            engagement: 14.2,
            watchTime: 4500,
            monetizationEarned: 120.50,
            retention: 55,
            followerGrowth: 340
        };
    }
};

// ===========================================================
// 7. ECHO / NOTE DROP SYSTEM
// ===========================================================
const echo = {
    create: async (content: string, visibility: 'public' | 'circles' | 'selected', allowRepost: boolean) => {
        const uid = getUid();
        const newEcho: Partial<Echo> = {
            creatorId: uid,
            username: auth.currentUser?.displayName || 'user',
            handle: auth.currentUser?.displayName?.toLowerCase().replace(/\s/g, '_') || 'user',
            avatar: auth.currentUser?.photoURL || '',
            content,
            visibility,
            timestamp: Date.now(),
            boostCount: 0,
            echoCount: 0,
            replyCount: 0,
        };
        await addDoc(collection(db, 'echos'), newEcho);
        await analytics.track('share', ['text'], 'echo');
    },

    boost: async (echoId: string) => {
        const uid = getUid();
        try {
            await updateDoc(doc(db, 'echos', echoId), { boostCount: increment(1) });
            await analytics.track('boost', [], 'echo');
        } catch (error: any) {
            if (error.code === 'not-found') return;
            throw error;
        }
    },

    flowline: async (mode: 'for_you' | 'following' = 'for_you'): Promise<Echo[]> => {
        const q = query(collection(db, 'echos'), orderBy('timestamp', 'desc'), limit(30));
        const snap = await getDocs(q);
        return snap.docs.map(d => ({ id: d.id, ...(d.data() as object) } as Echo));
    },
    
    fact_check: {
        request: async (echoId: string) => {
            try {
               await updateDoc(doc(db, 'echos', echoId), { factCheckStatus: 'unverified' }); 
            } catch(e) {}
        }
    }
};

const live = {
    start: async (title: string) => {
        const uid = getUid();
        const session: Partial<LiveSession> = {
            hostId: uid,
            title,
            viewers: 0,
            isActive: true,
            giftsReceived: 0
        };
        await addDoc(collection(db, 'lives'), session);
    }
};

const wallet = {
    balance: async () => ({ coins: 100, diamonds: 50, balance: 2.50 })
};

const gift = {
    send: async () => {} // Placeholder
};

const notification = {
    send: async (n: any) => {} // Placeholder
};

export const cmd = {
    teen,
    user,
    video,
    feed,
    product,
    creator,
    echo,
    live,
    wallet,
    gift,
    notification,
    analytics
};
