
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  signInWithPopup,
  GoogleAuthProvider,
  User as FirebaseUser,
  deleteUser,
  updatePassword,
  updateEmail,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  linkWithPhoneNumber,
  unlink,
  ConfirmationResult
} from "firebase/auth";
import { doc, getDoc, setDoc, updateDoc, deleteDoc } from "firebase/firestore";
import { auth, db, isFirebaseConfigured } from "./firebase";
import { AuthUser, UserProfile } from '../types';

const USERS_COLLECTION = 'users';

// --- HELPER TO MAP FIREBASE USER TO APP USER ---
const mapFirebaseUserToAuthUser = async (fbUser: FirebaseUser): Promise<AuthUser | null> => {
    const userDocRef = doc(db, USERS_COLLECTION, fbUser.uid);
    const userDoc = await getDoc(userDocRef);

    if (userDoc.exists()) {
        const data = userDoc.data() as UserProfile;
        return {
            ...data,
            email: fbUser.email || '',
            phoneNumber: fbUser.phoneNumber || data.phoneNumber || '',
            id: fbUser.uid
        };
    }
    return null;
};

// --- AUTH COMMANDS IMPLEMENTATION (v2.1) ---

export const authCommands = {
    // 1. Email & Password
    email: {
        signup: async (email: string, password: string, username: string) => {
            if (!isFirebaseConfigured()) throw new Error("Firebase not configured.");
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            return await _createUserProfile(userCredential.user, { username, email });
        },
        login: async (email: string, password: string) => {
            if (!isFirebaseConfigured()) throw new Error("Firebase not configured.");
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = await mapFirebaseUserToAuthUser(userCredential.user);
            if (!user) throw new Error("User profile not found.");
            if (user.isBanned) throw new Error("This account has been banned.");
            // Check 2FA
            if (user.settings?.twoFactorEnabled) {
                // In a real strict implementation, we would force an SMS challenge here
                // For this implementation, we return the user but UI should check this flag
                // and redirect to a "Verify 2FA" screen if needed.
                console.log("2FA is enabled for this user");
            }
            return user;
        }
    },

    // 2. Google Sign-In
    google: {
        signup: async () => {
             // Google signup/login is often merged in Firebase
             return await authCommands.google.login();
        },
        login: async () => {
            if (!isFirebaseConfigured()) throw new Error("Firebase not configured.");
            const provider = new GoogleAuthProvider();
            const result = await signInWithPopup(auth, provider);
            const fbUser = result.user;
            
            const existingUser = await mapFirebaseUserToAuthUser(fbUser);
            if (existingUser) {
                 if (existingUser.isBanned) throw new Error("Banned");
                 return existingUser;
            }
            // Create profile if new
            return await _createUserProfile(fbUser, { 
                username: fbUser.displayName || `User${fbUser.uid.slice(0,4)}`, 
                email: fbUser.email || '' 
            });
        }
    },

    // 3. Phone Number (SMS OTP)
    sms: {
        // Send Code (for Signup, Login, 2FA, Linking)
        send_code: async (phoneNumber: string, verifier: RecaptchaVerifier): Promise<ConfirmationResult> => {
            if (!isFirebaseConfigured()) throw new Error("Firebase not configured.");
            try {
                // Firebase handles the "sending" via their internal backend
                const confirmationResult = await signInWithPhoneNumber(auth, phoneNumber, verifier);
                return confirmationResult;
            } catch (error) {
                console.error("SMS Send Error:", error);
                throw new Error("Failed to send SMS. Check format or quota.");
            }
        },

        // Verify Code
        verify: async (confirmationResult: ConfirmationResult, code: string) => {
             const result = await confirmationResult.confirm(code);
             return result.user;
        }
    },

    signup: {
        phone: async (firebaseUser: FirebaseUser, username: string, dob: string) => {
            return await _createUserProfile(firebaseUser, { 
                username, 
                phoneNumber: firebaseUser.phoneNumber || '', 
                dateOfBirth: dob 
            });
        }
    },

    login: {
        phone: async (firebaseUser: FirebaseUser) => {
             const user = await mapFirebaseUserToAuthUser(firebaseUser);
             if (!user) throw new Error("Account not found. Please sign up.");
             if (user.isBanned) throw new Error("Banned");
             return user;
        }
    },

    phone: {
        link: async (phoneNumber: string, verifier: RecaptchaVerifier, codeInputProvider: () => Promise<string>) => {
             const user = auth.currentUser;
             if (!user) throw new Error("No user logged in");
             
             // 1. Send code to new phone
             const linkWithPhone = linkWithPhoneNumber(user, phoneNumber, verifier);
             
             // 2. Wait for code from UI (This flow usually requires the UI to handle the promise steps)
             // For this service structure, we return the confirmation object to the UI
             return linkWithPhone; 
        },
        unlink: async () => {
            const user = auth.currentUser;
            if (!user) throw new Error("No user logged in");
            // Check if user has other providers
            if (user.providerData.length <= 1) {
                throw new Error("Cannot unlink. Add another login method (Email/Google) first.");
            }
            
            // Find phone provider ID
            const phoneProvider = user.providerData.find(p => p.providerId === 'phone');
            if (phoneProvider) {
                await unlink(user, 'phone');
                await updateCurrentUser({ phoneNumber: '', isPhoneVerified: false });
            } else {
                throw new Error("No phone number linked.");
            }
        }
    },

    // 2FA
    twoFactor: {
        enable: async (userId: string) => {
             // In this client-side impl, we set a flag.
             // Ideally, verify phone ownership first (which we do before calling this)
             await updateCurrentUser({ settings: { twoFactorEnabled: true, twoFactorMethod: 'sms' } });
        },
        disable: async (userId: string) => {
             await updateCurrentUser({ settings: { twoFactorEnabled: false } });
        }
    },

    // Recovery
    recovery: {
        phone_restore_session: async (firebaseUser: FirebaseUser) => {
             // Basically logging in via phone to regain access
             const user = await mapFirebaseUserToAuthUser(firebaseUser);
             return user;
        }
    }
};

// --- INTERNAL HELPERS ---

const _createUserProfile = async (fbUser: FirebaseUser, additionalData: Partial<UserProfile>): Promise<AuthUser> => {
    let role: 'user' | 'super_admin' = 'user';
    let permissions = undefined;
    
    // Check Super Admin
    if (fbUser.email?.toLowerCase() === 'monroecpr@gmail.com') {
        role = 'super_admin';
        permissions = { canManageUsers: true, canManageContent: true, canManageAdmins: true, canViewAnalytics: true };
    }

    const newUserProfile: UserProfile = {
        id: fbUser.uid,
        username: additionalData.username || `User${fbUser.uid.slice(0,5)}`,
        handle: (additionalData.username || `User${fbUser.uid.slice(0,5)}`).toLowerCase().replace(/\s/g, '_'),
        avatar: fbUser.photoURL || `https://api.dicebear.com/7.x/avataaars/svg?seed=${fbUser.uid}`,
        role,
        permissions,
        following: [],
        followers: [],
        closeFriends: [],
        likes: 0,
        bio: 'New member',
        isBanned: false,
        email: fbUser.email || '',
        phoneNumber: fbUser.phoneNumber || additionalData.phoneNumber || '',
        isPhoneVerified: !!fbUser.phoneNumber,
        createdAt: Date.now(),
        settings: { twoFactorEnabled: false, theme: 'system' },
        ...additionalData
    };

    await setDoc(doc(db, USERS_COLLECTION, fbUser.uid), newUserProfile);
    return { ...newUserProfile, email: fbUser.email || '' };
};

// --- LEGACY EXPORTS (Maintaining compatibility for now) ---

export const login = authCommands.email.login;
export const signup = authCommands.email.signup;
export const loginWithGoogle = authCommands.google.login;
export const loginWithPhone = async () => { throw new Error("Use authCommands.sms flow"); }; // Deprecated legacy call
export const logout = async () => {
    await signOut(auth);
    localStorage.removeItem('postplays_cached_user');
};

export const getCurrentUser = (): AuthUser | null => {
    const cached = localStorage.getItem('postplays_cached_user');
    return cached ? JSON.parse(cached) : null;
};

export const updateCurrentUser = async (updates: any) => {
    const user = auth.currentUser;
    if (!user) return;
    
    // Deep merge logic simplified for this demo
    const userRef = doc(db, USERS_COLLECTION, user.uid);
    await updateDoc(userRef, updates);
    
    const cached = getCurrentUser();
    if (cached) {
        // Simple merge
        const merged = { ...cached, ...updates, settings: { ...cached.settings, ...updates.settings } };
        localStorage.setItem('postplays_cached_user', JSON.stringify(merged));
    }
};

export const deleteSelf = async () => {
    const user = auth.currentUser;
    if (!user) throw new Error("No user logged in");
    await deleteDoc(doc(db, USERS_COLLECTION, user.uid));
    await deleteUser(user);
    localStorage.removeItem('postplays_cached_user');
};

export const updateUserPassword = async (p: string) => {
    const user = auth.currentUser;
    if (!user) throw new Error("No user");
    await updatePassword(user, p);
};

export const updateUserEmail = async (e: string) => {
    const user = auth.currentUser;
    if (!user) throw new Error("No user");
    await updateEmail(user, e);
    await updateCurrentUser({ email: e });
};

// --- ADMIN ---
export const getAllUsers = async (): Promise<AuthUser[]> => { return []; };
export const updateUserRole = async (targetUserId: string, role: any, permissions?: any) => {
    const ref = doc(db, USERS_COLLECTION, targetUserId);
    await updateDoc(ref, { role, permissions });
};
export const banUser = async (targetUserId: string) => {
    const ref = doc(db, USERS_COLLECTION, targetUserId);
    await updateDoc(ref, { isBanned: true });
};
export const unbanUser = async (targetUserId: string) => {
    const ref = doc(db, USERS_COLLECTION, targetUserId);
    await updateDoc(ref, { isBanned: false });
};

export const initAuthListener = (callback: (user: AuthUser | null) => void) => {
    if (!isFirebaseConfigured()) return;
    return onAuthStateChanged(auth, async (fbUser) => {
        if (fbUser) {
            const user = await mapFirebaseUserToAuthUser(fbUser);
            if (user) {
                localStorage.setItem('postplays_cached_user', JSON.stringify(user));
                callback(user);
            } else {
                callback(null);
            }
        } else {
            localStorage.removeItem('postplays_cached_user');
            callback(null);
        }
    });
};
