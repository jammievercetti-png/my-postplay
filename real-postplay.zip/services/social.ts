
import { UserProfile, Post, Community, WeCareResult } from '../types';
import { db, isFirebaseConfigured } from './firebase';
import { collection, query, where, getDocs, doc, getDoc, updateDoc, arrayUnion, arrayRemove, orderBy, limit, addDoc } from "firebase/firestore";
import { getCurrentUser } from './auth';

const POSTS_COLLECTION = 'posts';
const USERS_COLLECTION = 'users';

export const getFeedPosts = async (): Promise<Post[]> => {
    if (!isFirebaseConfigured()) return [];
    try {
        const q = query(collection(db, POSTS_COLLECTION), orderBy('createdAt', 'desc'), limit(20));
        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => ({ id: doc.id, ...(doc.data() as object) } as Post));
    } catch (e) {
        console.warn("Feed fetch error:", e);
        return [];
    }
};

export const createPost = async (description: string, videoUrl: string, user: UserProfile) => {
    if (!isFirebaseConfigured()) return;
    const newPost: any = {
      type: 'video',
      videoUrl: videoUrl,
      username: user.username,
      description: description,
      music: 'Original Sound',
      likes: 0,
      comments: 0,
      shares: 0,
      avatar: user.avatar,
      isLiked: false,
      views: 0,
      createdAt: Date.now(),
      userId: user.id,
      privacy: 'public'
    };
    await addDoc(collection(db, POSTS_COLLECTION), newPost);
};

export const getUserById = async (id: string): Promise<UserProfile | null> => {
    if (!isFirebaseConfigured()) return null;
    try {
        const docRef = doc(db, USERS_COLLECTION, id);
        const snap = await getDoc(docRef);
        return snap.exists() ? (snap.data() as UserProfile) : null;
    } catch (e) {
        return null;
    }
};

export const getUserByHandle = async (handle: string): Promise<UserProfile | null> => {
    if (!isFirebaseConfigured()) return null;
    const q = query(collection(db, USERS_COLLECTION), where("handle", "==", handle), limit(1));
    const snap = await getDocs(q);
    if (!snap.empty) return snap.docs[0].data() as UserProfile;
    return null;
};

// Legacy Wrappers using the new Command structure where possible
import { cmd } from './commands';

export const followUser = async (targetUserId: string) => {
    await cmd.user.follow(targetUserId);
};

export const unfollowUser = async (targetUserId: string) => {
    await cmd.user.unfollow(targetUserId);
};

export const blockUser = async (targetUserId: string) => {
    await cmd.user.block(targetUserId);
};

export const toggleCloseFriend = async (targetUserId: string) => {
    const user = getCurrentUser();
    if (!user) return;
    if (user.closeFriends.includes(targetUserId)) {
        await cmd.user.close_friends.remove(targetUserId);
    } else {
        await cmd.user.close_friends.add(targetUserId);
    }
};

export const isBlocked = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.blockedUsers?.includes(targetUserId) || false;
};

export const isFollowing = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.following.includes(targetUserId) || false;
};

export const isCloseFriend = (targetUserId: string): boolean => {
    const user = getCurrentUser();
    return user?.closeFriends.includes(targetUserId) || false;
};

export const getFollowingFeed = async (allPosts: Post[]): Promise<Post[]> => {
    const user = getCurrentUser();
    if (!user) return [];
    // Basic filter for now, production should use backend query (see cmd.feed.following)
    return cmd.feed.following(); 
};

// --- COMMUNITIES & WE CARE MOCKS ---
// Kept simple for demo, but these should ideally be DB collections too
const MOCK_COMMUNITIES: Community[] = [
    { id: 'c1', name: 'Morning Yoga', members: 12400, description: 'Daily yoga routines.', coverImage: 'https://picsum.photos/seed/yoga/800/400', isJoined: true },
    { id: 'c2', name: 'Vegan Eats', members: 8900, description: 'Sharing vegan recipes.', coverImage: 'https://picsum.photos/seed/vegan/800/400' },
];

export const getCommunities = (): Community[] => MOCK_COMMUNITIES;

export const searchWeCare = async (query: string): Promise<WeCareResult> => {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve({
                question: query,
                summary: "Regular physical activity is one of the most important things you can do for your health.",
                sources: [
                    { name: 'CDC', url: 'https://www.cdc.gov' },
                    { name: 'WHO', url: 'https://www.who.int' }
                ]
            });
        }, 1500);
    });
};
