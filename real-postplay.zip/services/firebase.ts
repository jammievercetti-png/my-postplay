
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCBw_oE7lPMATFYFtRJu-7OT8H6YS4rTPU",
  authDomain: "postsplays-bfa8b.firebaseapp.com",
  projectId: "postsplays-bfa8b",
  storageBucket: "postsplays-bfa8b.firebasestorage.app",
  messagingSenderId: "1093759092232",
  appId: "1:1093759092232:web:555b3b10c8175b747ef3bd",
  measurementId: "G-XW3F04F1WS"
};

// Initialize Firebase with safety checks
let app;
let auth;
let db;
let storage;
let analytics;

try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);
  // Analytics is optional and might fail in some ad-blocked environments
  try {
    analytics = getAnalytics(app);
  } catch (e) {
    console.warn("Firebase Analytics failed to initialize", e);
  }
} catch (e) {
  console.error("Firebase initialization failed:", e);
}

// Helper to check if firebase is actually configured
export const isFirebaseConfigured = () => {
    return !!app;
};

export { app, auth, db, storage, analytics };
