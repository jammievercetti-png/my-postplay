
import { 
    updateCurrentUser, 
    deleteSelf, 
    updateUserPassword, 
    updateUserEmail,
    logout,
    authCommands
} from './auth';
import { db, auth } from './firebase';
import { addDoc, collection, doc, updateDoc } from 'firebase/firestore';
import { AuthUser } from '../types';

/**
 * SETTINGS COMMAND IMPLEMENTATION (v2.1)
 */

export const settings = {
    // --- ACCOUNT ---
    account: {
        manage: async (action: 'update_profile' | 'change_email' | 'delete_account', payload: any) => {
            switch (action) {
                case 'update_profile':
                    await updateCurrentUser(payload);
                    return { success: true, message: 'Profile updated' };
                
                case 'change_email':
                    await updateUserEmail(payload.new_email);
                    return { success: true, message: 'Email updated' };

                case 'delete_account':
                    if (payload.confirm) {
                        await deleteSelf();
                        return { success: true, message: 'Account deleted' };
                    }
                    throw new Error("Confirmation required");
                
                default:
                    throw new Error(`Unknown action: ${action}`);
            }
        }
    },

    // --- PRIVACY ---
    privacy: {
        set: async (
            option: 'account_visibility' | 'messages_from' | 'comments_from', 
            value: string,
            currentUser: AuthUser
        ) => {
            const keyMap: Record<string, keyof NonNullable<AuthUser['privacySettings']>> = {
                'account_visibility': 'accountVisibility',
                'messages_from': 'whoCanMessageMe',
                'comments_from': 'commentsFrom'
            };
            const key = keyMap[option];
            const privacySettings = { ...currentUser.privacySettings, [key]: value };
            
            await updateCurrentUser({ privacySettings: privacySettings });
            return { success: true, message: `Privacy updated` };
        }
    },

    // --- SECURITY (2FA & Password) ---
    security: {
        update: async (action: 'change_password' | '2fa_enable' | '2fa_disable', payload: any) => {
            switch (action) {
                case 'change_password':
                    await updateUserPassword(payload.new_password);
                    return { success: true, message: 'Password changed' };
                
                case '2fa_enable':
                    // Verify phone is required before this
                    if (!auth.currentUser?.phoneNumber) throw new Error("Link phone number first");
                    await authCommands.twoFactor.enable(auth.currentUser.uid);
                    return { success: true, message: '2FA Enabled via SMS' };
                
                case '2fa_disable':
                    await authCommands.twoFactor.disable(auth.currentUser!.uid);
                    return { success: true, message: '2FA Disabled' };

                default:
                    throw new Error(`Unknown action: ${action}`);
            }
        }
    },

    // --- VERIFICATION ---
    verification: {
        submit: async (payload: { fullName: string; idDocumentUrl: string; category: 'creator' | 'brand' }) => {
            await addDoc(collection(db, 'verification_requests'), {
                ...payload,
                userId: auth.currentUser?.uid,
                status: 'pending',
                timestamp: Date.now()
            });
            await updateCurrentUser({ verificationStatus: 'pending' });
            return { success: true, message: 'Verification request submitted' };
        },
        status: async (currentUser: AuthUser) => {
            return { status: currentUser.verificationStatus || 'none' };
        }
    },

    // --- DISPLAY ---
    display: {
        set: async (option: 'theme', value: 'dark' | 'light' | 'system') => {
            await updateCurrentUser({ settings: { theme: value } } as any);
            return { success: true, message: `Theme set` };
        }
    },

    // --- APP / LANGUAGE ---
    app: {
        language: {
            set: async (code: string) => {
                await updateCurrentUser({ settings: { language: code } } as any);
                return { success: true, message: `Language set` };
            }
        }
    },

    // --- SUPPORT ---
    support: {
        report: async (issue: { type: string; description: string; device?: string; os?: string }) => {
            await addDoc(collection(db, 'reports'), {
                ...issue,
                userId: auth.currentUser?.uid,
                timestamp: Date.now()
            });
            return { success: true, message: 'Report submitted' };
        }
    },

    navigation: {
        open: (route: string) => console.log(`Navigating to ${route}`)
    },

    auth: {
        logout: async () => {
            await logout();
            return { success: true, message: 'Logged out' };
        }
    }
};
