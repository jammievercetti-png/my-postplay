
import React, { useState, useEffect } from 'react';
import { authCommands } from '../services/auth';
import { AuthUser } from '../types';
import { GoogleIcon, PhoneIcon } from '../components/Icons';
import { RecaptchaVerifier, ConfirmationResult } from 'firebase/auth';
import { auth } from '../services/firebase';

declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier;
  }
}

interface AuthProps {
  onLoginSuccess: (user: AuthUser) => void;
}

export const Auth: React.FC<AuthProps> = ({ onLoginSuccess }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [authMethod, setAuthMethod] = useState<'email' | 'phone'>('email');
  
  // Fields
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [dob, setDob] = useState('');
  
  // State
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [showOtpInput, setShowOtpInput] = useState(false);
  const [confirmationResult, setConfirmationResult] = useState<ConfirmationResult | null>(null);

  useEffect(() => {
    if (!window.recaptchaVerifier && auth) {
      try {
        window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', {
            'size': 'invisible'
        });
      } catch (e) {
          console.error("Recaptcha Init Error:", e);
      }
    }
  }, []);

  const handleSendCode = async () => {
      if (!phone) { setError("Enter phone number"); return; }
      setLoading(true);
      setError('');
      try {
          // Clear previous instance to prevent conflicts
          if(window.recaptchaVerifier) window.recaptchaVerifier.clear();
          
          // Re-init
          window.recaptchaVerifier = new RecaptchaVerifier(auth, 'recaptcha-container', { 'size': 'invisible' });

          const formattedPhone = phone.startsWith('+') ? phone : `+1${phone}`; 
          const result = await authCommands.sms.send_code(formattedPhone, window.recaptchaVerifier);
          setConfirmationResult(result);
          setShowOtpInput(true);
          setLoading(false);
      } catch (err: any) {
          setError("SMS Error: " + (err.message || "Unknown error"));
          setLoading(false);
      }
  };

  const handleVerifyAndLogin = async () => {
      if (!confirmationResult || !otpCode) return;
      setLoading(true);
      try {
          const firebaseUser = await authCommands.sms.verify(confirmationResult, otpCode);
          let user: AuthUser;
          if (isLogin) {
              user = await authCommands.login.phone(firebaseUser);
          } else {
              if (!username || !dob) {
                  setError("Username and DOB required");
                  setLoading(false);
                  return;
              }
              user = await authCommands.signup.phone(firebaseUser, username, dob);
          }
          onLoginSuccess(user);
      } catch (err: any) {
          setError("Verification failed: " + err.message);
          setLoading(false);
      }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (authMethod === 'phone') {
        if (showOtpInput) handleVerifyAndLogin();
        else handleSendCode();
        return;
    }

    setLoading(true);
    setError('');
    
    try {
      let user: AuthUser;
      if (isLogin) {
         user = await authCommands.email.login(email, password);
      } else {
         user = await authCommands.email.signup(email, password, username);
      }
      onLoginSuccess(user);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
        const user = await authCommands.google.login();
        onLoginSuccess(user);
    } catch (err: any) {
        setError("Google Sign In: " + err.message);
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="h-full w-full bg-white flex flex-col items-center justify-center p-8 font-sans overflow-y-auto text-black">
       <div id="recaptcha-container"></div>
       
       <div className="w-20 h-20 bg-black rounded-xl mb-6 flex items-center justify-center shadow-lg shrink-0">
          <span className="text-white font-black text-xl tracking-tighter">PP</span>
       </div>
       
       <h1 className="text-2xl font-bold mb-2 tracking-tight">
         {isLogin ? 'Welcome back' : 'Create account'}
       </h1>

       <button 
         onClick={handleGoogleLogin}
         disabled={loading}
         className="w-full max-w-sm mb-6 flex items-center justify-center gap-3 bg-white border border-gray-300 p-3 rounded-lg text-sm font-bold text-gray-700 hover:bg-gray-50 transition-colors shadow-sm"
       >
         <GoogleIcon className="w-5 h-5" />
         Continue with Google
       </button>

       <div className="w-full max-w-sm flex items-center gap-2 mb-6">
          <div className="h-px bg-gray-200 flex-1"></div>
          <span className="text-xs text-gray-400 font-medium">OR</span>
          <div className="h-px bg-gray-200 flex-1"></div>
       </div>

       <div className="w-full max-w-sm flex mb-4 border-b border-gray-200">
          <button onClick={() => { setAuthMethod('email'); setShowOtpInput(false); setError(''); }} className={`flex-1 pb-2 text-sm font-bold ${authMethod === 'email' ? 'text-black border-b-2 border-black' : 'text-gray-400'}`}>Email</button>
          <button onClick={() => { setAuthMethod('phone'); setShowOtpInput(false); setError(''); }} className={`flex-1 pb-2 text-sm font-bold ${authMethod === 'phone' ? 'text-black border-b-2 border-black' : 'text-gray-400'}`}>Phone</button>
       </div>

       <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-4">
          {authMethod === 'email' && (
             <>
                {!isLogin && <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" placeholder="Username" required />}
                <input type="email" value={email} onChange={e => setEmail(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" placeholder="Email" required />
                <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" placeholder="Password" required />
             </>
          )}

          {authMethod === 'phone' && (
             <>
                {!showOtpInput ? (
                    <input type="tel" value={phone} onChange={e => setPhone(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" placeholder="Phone (e.g. 5550199)" required />
                ) : (
                    <input type="text" value={otpCode} onChange={e => setOtpCode(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-center tracking-widest font-bold text-black" placeholder="123456" required />
                )}
                
                {!isLogin && !showOtpInput && (
                    <>
                        <input type="text" value={username} onChange={e => setUsername(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" placeholder="Username" />
                        <input type="date" value={dob} onChange={e => setDob(e.target.value)} className="w-full p-3 bg-gray-50 border border-gray-200 rounded-lg text-sm text-black" />
                    </>
                )}
             </>
          )}

          {error && <p className="text-red-500 text-xs text-center font-medium bg-red-50 p-2 rounded">{error}</p>}

          <button type="submit" disabled={loading} className="w-full bg-black text-white p-3.5 rounded-lg font-bold text-sm hover:opacity-90 disabled:opacity-50 transition-opacity shadow-md">
            {loading ? 'Processing...' : (authMethod === 'phone' ? (showOtpInput ? 'Verify' : 'Send Code') : (isLogin ? 'Log In' : 'Sign Up'))}
          </button>
       </form>

       <button className="mt-6 text-sm text-gray-600 font-medium" onClick={() => { setIsLogin(!isLogin); setError(''); setShowOtpInput(false); }}>
         {isLogin ? <span>No account? <span className="text-[#fe2c55] font-bold">Sign up</span></span> : <span>Have account? <span className="text-[#fe2c55] font-bold">Log in</span></span>}
       </button>
    </div>
  );
};
