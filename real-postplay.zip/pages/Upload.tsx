
import React, { useRef, useState, useEffect } from 'react';
import { 
  BeautyIcon, TimerIcon, ChevronLeftIcon, FlashIcon, 
  FlipIcon, FlashOffIcon, MusicIcon, FilterIcon, 
  XIcon, MagicIcon, FeatherIcon
} from '../components/Icons';
import { cmd } from '../services/commands';

interface UploadProps {
  onCancel: () => void;
  onPost: (description: string, videoUrl: string) => void;
}

const SnapButton: React.FC<{ icon: React.ReactNode; label?: string; active?: boolean; onClick?: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick} 
    className={`flex flex-col items-center justify-center transition-all active:scale-95 ${active ? 'text-yellow-400' : 'text-white'}`}
  >
    <div className={`w-10 h-10 flex items-center justify-center rounded-full glass-capsule ${active ? 'bg-yellow-400/20 border-yellow-400/50' : ''}`}>
       {icon}
    </div>
    {label && <span className="text-[9px] font-bold mt-1 shadow-black drop-shadow-md tracking-wider uppercase opacity-80">{label}</span>}
  </button>
);

// CHANGED 'SNAP' TO 'POST'
const MODES = ['POST', 'STORY', 'ECHO', 'LIVE'];

export const Upload: React.FC<UploadProps> = ({ onCancel, onPost }) => {
  const videoRef = useRef<HTMLVideoElement>(null); 
  const canvasRef = useRef<HTMLCanvasElement>(null); 
  const fileInputRef = useRef<HTMLInputElement>(null);
  const animationFrameRef = useRef<number>(0);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [step, setStep] = useState<'capture' | 'details'>('capture');
  
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');
  const [flashOn, setFlashOn] = useState(false);
  const [activeFilterId, setActiveFilterId] = useState('normal');
  const [caption, setCaption] = useState('');
  const [cameraMode, setCameraMode] = useState(0); 

  // Echo Mode State
  const [echoText, setEchoText] = useState('');
  const [echoVisibility, setEchoVisibility] = useState<'public' | 'circles'>('public');

  const startCamera = async () => {
    // If switching to ECHO mode, stop camera to save battery/resources
    if (MODES[cameraMode] === 'ECHO') {
        if (stream) stream.getTracks().forEach(track => track.stop());
        return;
    }

    if (stream && stream.active) return; // Already running

    const constraints = { video: { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: true };
    try {
      const newStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(newStream);
      if (videoRef.current) { videoRef.current.srcObject = newStream; videoRef.current.play(); }
    } catch (err) {
      try {
        const vStream = await navigator.mediaDevices.getUserMedia({ ...constraints, audio: false });
        setStream(vStream);
        if (videoRef.current) { videoRef.current.srcObject = vStream; videoRef.current.play(); }
      } catch (e) { console.error("Camera denied"); }
    }
  };

  useEffect(() => { 
      startCamera(); 
      return () => { 
          if (stream) stream.getTracks().forEach(t => t.stop()); 
          cancelAnimationFrame(animationFrameRef.current); 
      }; 
  }, [facingMode, cameraMode]);

  useEffect(() => {
    const render = () => {
      if (!videoRef.current || !canvasRef.current || MODES[cameraMode] === 'ECHO') return;
      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;
      const video = videoRef.current;
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        canvasRef.current.width = video.videoWidth;
        canvasRef.current.height = video.videoHeight;
        
        if (activeFilterId !== 'normal') {
            ctx.filter = activeFilterId === 'vintage' ? 'sepia(0.5) contrast(1.2)' : 'none';
        } else {
            ctx.filter = 'none';
        }

        ctx.drawImage(video, 0, 0, canvasRef.current.width, canvasRef.current.height);
        
        if (flashOn) { ctx.fillStyle = 'rgba(255, 255, 255, 0.1)'; ctx.fillRect(0,0,canvasRef.current.width,canvasRef.current.height); }
      }
      animationFrameRef.current = requestAnimationFrame(render);
    };
    render();
  }, [flashOn, activeFilterId, cameraMode]);

  const handlePostEcho = async () => {
      if (!echoText.trim()) return;
      try {
          await cmd.echo.create(echoText, echoVisibility as any, true);
          alert('Echo Dropped!');
          onCancel();
      } catch (e) {
          alert('Failed to drop note');
      }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          const url = URL.createObjectURL(file);
          onPost('Uploaded from Gallery', url);
      }
  };

  const isEchoMode = MODES[cameraMode] === 'ECHO';

  return (
    <div className={`h-full w-full relative overflow-hidden select-none touch-none transition-colors duration-500 ${isEchoMode ? 'bg-gradient-to-br from-gray-900 to-black' : 'bg-black'}`}>
       
       {/* Camera Elements */}
       <div className={`absolute inset-0 transition-opacity duration-300 ${isEchoMode ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
           <input ref={fileInputRef} type="file" accept="video/*" className="hidden" onChange={handleFileUpload} />
           <video ref={videoRef} className="absolute opacity-0 pointer-events-none" autoPlay playsInline muted />
           <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover" />
           
           <div className="absolute top-20 right-4 z-20 flex flex-col gap-6 items-center">
              <SnapButton icon={<FlipIcon className="w-5 h-5" />} label="Flip" onClick={() => setFacingMode(m => m === 'user' ? 'environment' : 'user')} />
              <SnapButton icon={<BeautyIcon className="w-5 h-5" />} label="Beauty" />
              <SnapButton icon={flashOn ? <FlashIcon active className="w-5 h-5" /> : <FlashOffIcon className="w-5 h-5" />} label="Flash" onClick={() => setFlashOn(!flashOn)} />
              <SnapButton icon={<FilterIcon className="w-5 h-5" />} label="Filter" active={activeFilterId !== 'normal'} onClick={() => setActiveFilterId(prev => prev === 'normal' ? 'vintage' : 'normal')} />
              <SnapButton icon={<TimerIcon className="w-5 h-5" />} label="Timer" />
           </div>
       </div>

       {/* Close Button */}
       <div className="absolute top-4 left-4 z-30">
          <button onClick={onCancel}><XIcon className="w-8 h-8 text-white drop-shadow-md" /></button>
       </div>

       {/* ECHO EDITOR MODE */}
       {isEchoMode && (
           <div className="absolute inset-0 z-10 flex flex-col justify-center items-center p-6 animate-fade-in">
               <div className="w-full max-w-sm">
                   <h2 className="text-white/50 font-bold text-xs uppercase tracking-widest mb-4 text-center">New Note Drop</h2>
                   
                   <div className="glass-panel p-6 rounded-3xl border border-white/20 shadow-2xl relative">
                       <textarea 
                           value={echoText} 
                           onChange={(e) => setEchoText(e.target.value)}
                           className="w-full bg-transparent text-white text-lg font-medium placeholder-white/30 resize-none focus:outline-none min-h-[150px]"
                           placeholder="Drop what's on your mind..."
                           maxLength={280}
                       />
                       <div className="flex justify-between items-center mt-4 pt-4 border-t border-white/10">
                           <button 
                               onClick={() => setEchoVisibility(v => v === 'public' ? 'circles' : 'public')}
                               className="text-xs font-bold text-gray-400 bg-white/5 px-3 py-1.5 rounded-full hover:bg-white/10 transition-colors"
                           >
                               {echoVisibility === 'public' ? 'Public Drop' : 'Circles Only'}
                           </button>
                           <span className="text-xs text-gray-500">{echoText.length}/280</span>
                       </div>
                   </div>

                   <button 
                       onClick={handlePostEcho}
                       disabled={!echoText.trim()}
                       className="w-full mt-6 bg-[#fe2c55] text-white font-bold py-4 rounded-full shadow-lg disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                   >
                       <FeatherIcon className="w-5 h-5" />
                       DROP NOTE
                   </button>
               </div>
           </div>
       )}

       {/* Bottom Control Bar */}
       <div className="absolute bottom-0 left-0 right-0 z-20 pb-10 pt-20 bg-gradient-to-t from-black via-black/50 to-transparent">
          <div className="flex justify-center gap-8 mb-8">
             {MODES.map((mode, i) => (
               <button key={mode} onClick={() => setCameraMode(i)} className={`text-xs font-black tracking-widest transition-all ${cameraMode === i ? 'text-white scale-110 drop-shadow-[0_0_10px_rgba(255,255,255,0.8)]' : 'text-white/40'}`}>
                 {mode}
               </button>
             ))}
          </div>

          {!isEchoMode && (
              <div className="flex items-center justify-around px-8">
                 <button onClick={() => fileInputRef.current?.click()} className="flex flex-col items-center gap-1 group">
                    <div className="w-10 h-10 rounded-[10px] border-2 border-white/50 bg-white/10 backdrop-blur-md overflow-hidden flex items-center justify-center">
                        <div className="w-full h-full bg-gradient-to-tr from-purple-500 to-blue-500 opacity-50"></div>
                    </div>
                    <span className="text-[9px] font-bold text-white uppercase tracking-wider">Load</span>
                 </button>

                 <button 
                   onClick={() => alert("Recording would start here in production app")} 
                   className={`w-20 h-20 rounded-full border-4 flex items-center justify-center transition-all duration-200 border-white`}
                 >
                    <div className={`rounded-full w-16 h-16 bg-white`}></div>
                 </button>

                 <button className="flex flex-col items-center gap-1">
                    <div className="w-10 h-10 rounded-full border-2 border-white/50 flex items-center justify-center glass-capsule">
                       <MagicIcon className="w-5 h-5 text-yellow-400" />
                    </div>
                    <span className="text-[9px] font-bold text-white uppercase tracking-wider">FX</span>
                 </button>
              </div>
          )}
       </div>
    </div>
  );
};
