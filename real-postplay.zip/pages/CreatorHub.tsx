
import React, { useState } from 'react';
import { ChartIcon, ChevronLeftIcon, BellIcon, UserIcon, HeartIcon } from '../components/Icons';

export const CreatorHub: React.FC<{ onBack: () => void }> = ({ onBack }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeTab, setActiveTab] = useState<'all' | 'likes' | 'mentions'>('all');

  // Simulated notifications data
  const NOTIFICATIONS = [
      { id: 1, type: 'follow', user: 'sarah_j', text: 'started following you', time: '2m' },
      { id: 2, type: 'like', user: 'mike_t', text: 'liked your video', time: '1h' },
      { id: 3, type: 'system', user: 'System', text: 'Your video is trending! 🚀', time: '2h' },
      { id: 4, type: 'like', user: 'anna_b', text: 'liked your video', time: '3h' },
  ];

  const getFilteredNotifications = () => {
      if (activeTab === 'likes') return NOTIFICATIONS.filter(n => n.type === 'like');
      if (activeTab === 'mentions') return NOTIFICATIONS.filter(n => n.type === 'mention' || n.type === 'follow');
      return NOTIFICATIONS;
  };

  return (
    <div className="h-full w-full bg-gray-50 flex flex-col font-sans overflow-hidden relative">
       {/* Header */}
       <div className="bg-white p-4 flex items-center justify-between border-b sticky top-0 z-10">
          <div className="flex items-center gap-4">
            <button onClick={onBack}><ChevronLeftIcon className="w-6 h-6 text-black" /></button>
            <h1 className="font-bold text-lg">Creator Center</h1>
          </div>
          <button onClick={() => setShowNotifications(true)} className="relative">
             <BellIcon className="w-6 h-6 text-black" />
             <div className="absolute top-0 right-0 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-white"></div>
          </button>
       </div>

       <div className="flex-1 overflow-y-auto p-4 space-y-6 pb-20">
          
          {/* Overview Cards */}
          <div className="grid grid-cols-2 gap-4">
             <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <div className="text-gray-500 text-xs font-bold uppercase mb-1">Total Views</div>
                <div className="text-2xl font-black text-black">1.2M</div>
                <div className="text-green-500 text-xs font-medium mt-1">↑ 12% vs last week</div>
             </div>
             <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
                <div className="text-gray-500 text-xs font-bold uppercase mb-1">Net Revenue</div>
                <div className="text-2xl font-black text-black">$8,450</div>
                <div className="text-green-500 text-xs font-medium mt-1">↑ 5% vs last week</div>
             </div>
          </div>

          {/* Chart Simulation */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
             <div className="flex justify-between items-center mb-6">
                <h3 className="font-bold">Engagement Over Time</h3>
                <ChartIcon className="text-gray-400 w-5 h-5" />
             </div>
             <div className="h-32 flex items-end justify-between gap-2 px-2">
                {[40, 65, 34, 78, 56, 90, 85].map((h, i) => (
                   <div key={i} className="w-full bg-blue-500 rounded-t-sm opacity-80 hover:opacity-100 transition-opacity" style={{ height: `${h}%` }}></div>
                ))}
             </div>
             <div className="flex justify-between mt-2 text-xs text-gray-400">
                <span>Mon</span><span>Tue</span><span>Wed</span><span>Thu</span><span>Fri</span><span>Sat</span><span>Sun</span>
             </div>
          </div>

          {/* Recent Products */}
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
             <h3 className="font-bold mb-4">Top Selling Products</h3>
             {[1, 2, 3].map(i => (
                <div key={i} className="flex items-center gap-3 mb-4 last:mb-0">
                   <div className="w-12 h-12 bg-gray-100 rounded-md">
                      <img src={`https://picsum.photos/seed/p${i}/100`} className="w-full h-full object-cover rounded-md" />
                   </div>
                   <div className="flex-1">
                      <div className="font-bold text-sm">Viral Product #{i}</div>
                      <div className="text-xs text-gray-500">$24.99 • 450 sold</div>
                   </div>
                   <div className="font-bold text-green-600 text-sm">+$450</div>
                </div>
             ))}
          </div>
       </div>

       {/* Notifications Drawer */}
       {showNotifications && (
           <div className="absolute inset-0 z-50 flex justify-end">
               <div className="absolute inset-0 bg-black/50 transition-opacity" onClick={() => setShowNotifications(false)}></div>
               <div className="bg-white w-[85%] h-full relative z-10 animate-slide-left shadow-2xl flex flex-col">
                   <div className="p-4 border-b flex items-center justify-between">
                       <h2 className="font-bold text-lg">Activity</h2>
                       <button onClick={() => setShowNotifications(false)} className="text-gray-500">Close</button>
                   </div>
                   
                   <div className="flex p-2 gap-2 border-b overflow-x-auto no-scrollbar">
                       {['all', 'likes', 'mentions'].map(tab => (
                           <button 
                                key={tab} 
                                onClick={() => setActiveTab(tab as any)}
                                className={`px-4 py-1.5 rounded-full text-xs font-bold capitalize ${activeTab === tab ? 'bg-black text-white' : 'bg-gray-100 text-gray-600'}`}
                            >
                               {tab}
                           </button>
                       ))}
                   </div>

                   <div className="flex-1 overflow-y-auto p-2">
                       {getFilteredNotifications().map(notif => (
                           <div key={notif.id} className="flex items-start gap-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer">
                               {notif.type === 'system' ? (
                                   <div className="w-10 h-10 rounded-full bg-black flex items-center justify-center text-white font-bold text-xs">PP</div>
                               ) : (
                                   <img src={`https://picsum.photos/seed/${notif.user}/100`} className="w-10 h-10 rounded-full object-cover border border-gray-200" />
                               )}
                               <div className="flex-1">
                                   <div className="text-sm">
                                       <span className="font-bold">{notif.user}</span> <span className="text-gray-600">{notif.text}</span>
                                   </div>
                                   <div className="text-xs text-gray-400 mt-1">{notif.time} ago</div>
                               </div>
                               {notif.type === 'like' && <div className="w-10 h-10 bg-gray-200 rounded"><img src={`https://picsum.photos/seed/v${notif.id}/100`} className="w-full h-full object-cover rounded" /></div>}
                               {notif.type === 'follow' && <button className="bg-[#fe2c55] text-white text-xs font-bold px-3 py-1 rounded-sm">Follow</button>}
                           </div>
                       ))}
                       {getFilteredNotifications().length === 0 && (
                           <div className="text-center text-gray-400 py-10 text-sm">No notifications yet</div>
                       )}
                   </div>
               </div>
           </div>
       )}
    </div>
  );
};
