import React, { useState, useEffect } from 'react';
import { AuthUser } from '../types';
import { getAllUsers, updateUserRole, banUser, unbanUser } from '../services/auth';
import { SearchIcon, ShieldIcon, TrashIcon, UserIcon, CheckIcon, LockIcon, ChevronLeftIcon } from '../components/Icons';

interface AdminDashboardProps {
  currentUser: AuthUser;
  onBack: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ currentUser, onBack }) => {
  const [users, setUsers] = useState<AuthUser[]>([]);
  const [activeTab, setActiveTab] = useState<'users' | 'admins' | 'stats'>('stats');
  const [search, setSearch] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const data = await getAllUsers();
    setUsers(data);
  };

  const handlePromote = async (userId: string) => {
    if (!currentUser.permissions?.canManageAdmins) {
        alert("Permission denied");
        return;
    }
    await updateUserRole(userId, 'admin', { canManageUsers: true, canManageContent: true, canManageAdmins: false, canViewAnalytics: true });
    loadData();
  };

  const handleDemote = async (userId: string) => {
    if (!currentUser.permissions?.canManageAdmins) return;
    await updateUserRole(userId, 'user');
    loadData();
  };

  const handleBan = async (userId: string) => {
    if (confirm('Are you sure you want to ban this user?')) {
        await banUser(userId);
        loadData();
    }
  };

  const handleUnban = async (userId: string) => {
      await unbanUser(userId);
      loadData();
  };

  const filteredUsers = users.filter(u => 
    u.username.toLowerCase().includes(search.toLowerCase()) || 
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  const stats = {
      totalUsers: users.length,
      admins: users.filter(u => u.role === 'admin' || u.role === 'super_admin').length,
      banned: users.filter(u => u.isBanned).length,
      newToday: users.filter(u => Date.now() - (u.createdAt || 0) < 86400000).length
  };

  if (currentUser.role !== 'super_admin' && currentUser.role !== 'admin') {
      return <div className="p-10 text-center text-red-500 font-bold">Access Denied</div>;
  }

  return (
    <div className="h-full w-full bg-gray-50 flex flex-col font-sans">
      {/* Header */}
      <div className="bg-black text-white p-4 flex items-center justify-between shadow-md">
         <div className="flex items-center gap-3">
             <button onClick={onBack}><ChevronLeftIcon className="w-6 h-6 text-white" /></button>
             <ShieldIcon className="w-6 h-6 text-yellow-400" />
             <div>
                <h1 className="font-bold text-lg leading-tight">Admin Portal</h1>
                <p className="text-[10px] opacity-70">Logged in as {currentUser.email}</p>
             </div>
         </div>
      </div>

      {/* Tabs */}
      <div className="flex bg-white border-b border-gray-200">
         <button onClick={() => setActiveTab('stats')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'stats' ? 'text-black border-b-2 border-black' : 'text-gray-400'}`}>Overview</button>
         <button onClick={() => setActiveTab('users')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'users' ? 'text-black border-b-2 border-black' : 'text-gray-400'}`}>User Management</button>
         <button onClick={() => setActiveTab('admins')} className={`flex-1 py-3 text-sm font-bold ${activeTab === 'admins' ? 'text-black border-b-2 border-black' : 'text-gray-400'}`}>Admins</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
          
          {/* STATS VIEW */}
          {activeTab === 'stats' && (
              <div className="grid grid-cols-2 gap-4">
                  <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-blue-500">
                      <div className="text-gray-500 text-xs font-bold uppercase">Total Users</div>
                      <div className="text-2xl font-black">{stats.totalUsers}</div>
                  </div>
                  <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-yellow-500">
                      <div className="text-gray-500 text-xs font-bold uppercase">Admins</div>
                      <div className="text-2xl font-black">{stats.admins}</div>
                  </div>
                  <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-red-500">
                      <div className="text-gray-500 text-xs font-bold uppercase">Banned</div>
                      <div className="text-2xl font-black">{stats.banned}</div>
                  </div>
                  <div className="bg-white p-4 rounded-xl shadow-sm border-l-4 border-green-500">
                      <div className="text-gray-500 text-xs font-bold uppercase">New Today</div>
                      <div className="text-2xl font-black">{stats.newToday}</div>
                  </div>

                  <div className="col-span-2 bg-white p-4 rounded-xl shadow-sm mt-4">
                      <h3 className="font-bold mb-2">System Status</h3>
                      <div className="flex items-center gap-2 text-sm text-green-600 font-medium">
                          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                          All Systems Operational
                      </div>
                      <div className="mt-2 text-xs text-gray-400">Database: Local Storage Persistence</div>
                  </div>
              </div>
          )}

          {/* USERS VIEW */}
          {activeTab === 'users' && (
             <div className="space-y-4">
                 <div className="relative">
                     <input 
                       value={search} 
                       onChange={(e) => setSearch(e.target.value)}
                       placeholder="Search users..." 
                       className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:outline-none focus:border-black text-sm"
                     />
                     <SearchIcon className="w-4 h-4 text-gray-400 absolute left-3 top-2.5" />
                 </div>

                 {filteredUsers.map(user => (
                     <div key={user.id} className="bg-white p-3 rounded-xl shadow-sm flex items-center gap-3">
                         <img src={user.avatar} className="w-10 h-10 rounded-full bg-gray-200" />
                         <div className="flex-1 min-w-0">
                             <div className="flex items-center gap-2">
                                <span className="font-bold text-sm truncate">{user.username}</span>
                                {user.role === 'super_admin' && <ShieldIcon className="w-3 h-3 text-purple-600" />}
                                {user.role === 'admin' && <ShieldIcon className="w-3 h-3 text-blue-500" />}
                             </div>
                             <div className="text-xs text-gray-500 truncate">{user.email}</div>
                             {user.isBanned && <span className="text-[10px] bg-red-100 text-red-600 px-1 rounded font-bold">BANNED</span>}
                         </div>
                         
                         {user.role !== 'super_admin' && (
                             <div className="flex gap-2">
                                 {user.isBanned ? (
                                    <button onClick={() => handleUnban(user.id)} className="p-2 bg-green-100 text-green-600 rounded-lg"><CheckIcon className="w-4 h-4" /></button>
                                 ) : (
                                    <button onClick={() => handleBan(user.id)} className="p-2 bg-red-100 text-red-600 rounded-lg"><TrashIcon className="w-4 h-4" /></button>
                                 )}
                                 
                                 {currentUser.permissions?.canManageAdmins && user.role === 'user' && (
                                     <button onClick={() => handlePromote(user.id)} className="p-2 bg-blue-100 text-blue-600 rounded-lg text-[10px] font-bold">Make Admin</button>
                                 )}
                             </div>
                         )}
                     </div>
                 ))}
             </div>
          )}

          {/* ADMINS VIEW */}
          {activeTab === 'admins' && (
              <div className="space-y-4">
                 <div className="bg-blue-50 p-3 rounded-lg text-xs text-blue-700 mb-4">
                    Only Super Admins can add or remove other administrators.
                 </div>
                 {users.filter(u => u.role === 'admin' || u.role === 'super_admin').map(admin => (
                     <div key={admin.id} className="bg-white p-4 rounded-xl shadow-sm flex items-center gap-3 border border-blue-100">
                         <img src={admin.avatar} className="w-12 h-12 rounded-full bg-gray-200" />
                         <div className="flex-1">
                             <div className="font-bold text-sm flex items-center gap-1">
                                 {admin.username}
                                 {admin.role === 'super_admin' ? <span className="bg-purple-100 text-purple-700 text-[9px] px-1 rounded">SUPER</span> : <span className="bg-blue-100 text-blue-700 text-[9px] px-1 rounded">ADMIN</span>}
                             </div>
                             <div className="text-xs text-gray-500">{admin.email}</div>
                         </div>
                         {currentUser.role === 'super_admin' && admin.role !== 'super_admin' && (
                             <button onClick={() => handleDemote(admin.id)} className="text-red-500 text-xs font-bold border border-red-200 px-3 py-1 rounded-full">
                                 Remove
                             </button>
                         )}
                     </div>
                 ))}
              </div>
          )}
      </div>
    </div>
  );
};