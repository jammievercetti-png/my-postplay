
import React, { useState, useEffect } from 'react';
import { SearchIcon, PlusIcon, HandHeartIcon, MapIcon, HeartIcon, MapPinIcon, OrbIcon } from '../components/Icons';
import { Community, WeCareResult, Post } from '../types';
import { getCommunities, searchWeCare } from '../services/social';
import { cmd } from '../services/commands';
import { Shop } from './Shop';
import { MapExplorer } from './MapExplorer'; 
import { Feed } from '../components/VideoFeed';

const TABS = [
    { id: 'trending', label: 'Trending' },
    { id: 'fitness', label: 'Fitness' },
    { id: 'sports', label: 'Sports' },
    { id: 'communities', label: 'Communities' },
    { id: 'shop', label: 'Shop' },
    { id: 'we_care', label: 'We Care' }
];

interface DiscoverProps {
    onNavigateToMap?: () => void;
    setFullScreen: (isFull: boolean) => void;
}

export const Discover: React.FC<DiscoverProps> = ({ onNavigateToMap, setFullScreen }) => {
  const [headerTab, setHeaderTab] = useState<'flows' | 'nearby'>('flows');
  const [activeTab, setActiveTab] = useState('trending');
  
  // Discover Grid State
  const [discoverPosts, setDiscoverPosts] = useState<Post[]>([]);
  const [nearbyPosts, setNearbyPosts] = useState<Post[]>([]);
  const [activePostIndex, setActivePostIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);

  // We Care State
  const [weCareQuery, setWeCareQuery] = useState('');
  const [weCareResult, setWeCareResult] = useState<WeCareResult | null>(null);
  const [loadingWeCare, setLoadingWeCare] = useState(false);

  // Communities State
  const communities = getCommunities();
  const [activeCommunity, setActiveCommunity] = useState<Community | null>(null);

  useEffect(() => {
      // Load nearby posts when tab switches
      if (headerTab === 'nearby') {
          setLoading(true);
          cmd.feed.nearby().then(posts => {
              setNearbyPosts(posts);
              setLoading(false);
          });
      }
  }, [headerTab]);

  useEffect(() => {
      if (headerTab === 'flows' && ['trending', 'fitness', 'sports'].includes(activeTab)) {
          setLoading(true);
          // In production, send category filter to command
          // cmd.feed.category(activeTab)
          cmd.feed.for_you().then(posts => {
              setDiscoverPosts(posts);
              setLoading(false);
          });
      }
  }, [headerTab, activeTab]);

  const handleTabChange = (tabId: string) => {
      setActiveTab(tabId);
      setActiveCommunity(null);
  };

  const handleWeCareSearch = async () => {
     if (!weCareQuery.trim()) return;
     setLoadingWeCare(true);
     const res = await searchWeCare(weCareQuery);
     setWeCareResult(res);
     setLoadingWeCare(false);
  };

  const handlePostClick = (index: number) => {
      setActivePostIndex(index);
      setFullScreen(true);
  };

  const closeFullScreen = () => {
      setActivePostIndex(null);
      setFullScreen(false);
  };

  const renderContent = () => {
      if (headerTab === 'nearby') {
          return (
              <div className="pb-28 no-scrollbar bg-[#f2f2f2] p-2">
                  {loading && <div className="text-center py-10 text-gray-400">Finding nearby flows...</div>}
                  <div className="columns-2 gap-2 space-y-2">
                      {!loading && nearbyPosts.length === 0 && (
                          <div className="col-span-2 text-center text-gray-400 py-10">No nearby flows found</div>
                      )}
                      {nearbyPosts.map((post, i) => (
                          <div 
                            key={post.id} 
                            className="break-inside-avoid bg-white rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.1)] cursor-pointer hover:shadow-md transition-shadow relative"
                            onClick={() => handlePostClick(i)}
                          >
                              <div className="absolute top-2 left-2 bg-black/50 backdrop-blur-sm text-white text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 z-10">
                                  <MapPinIcon className="w-3 h-3" />
                                  {post.location}
                              </div>
                              <div className="w-full bg-gray-200">
                                  {/* Use video as thumb or placeholder */}
                                  <video src={post.videoUrl} className="w-full h-auto object-cover block" muted />
                              </div>
                              <div className="p-2.5">
                                  <h3 className="font-medium text-sm text-gray-900 leading-snug line-clamp-2 mb-2">
                                      {post.description}
                                  </h3>
                                  <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-1.5 min-w-0">
                                          <img src={post.avatar} className="w-4 h-4 rounded-full border border-gray-100 flex-shrink-0" />
                                          <span className="text-[10px] text-gray-500 truncate">{post.username}</span>
                                      </div>
                                      <div className="flex items-center gap-0.5 flex-shrink-0">
                                          <HeartIcon className="w-3 h-3 text-gray-400" />
                                          <span className="text-[10px] text-gray-500">{post.likes}</span>
                                      </div>
                                  </div>
                              </div>
                          </div>
                      ))}
                  </div>
              </div>
          );
      }

      switch(activeTab) {
          case 'shop':
              return <div className="h-full relative"><Shop /></div>;
          
          case 'communities':
              if (activeCommunity) {
                  return (
                      <div className="p-4 animate-slide-up">
                          <button onClick={() => setActiveCommunity(null)} className="text-sm text-gray-500 mb-4 flex items-center gap-1">← Back</button>
                          <div className="relative h-48 rounded-xl overflow-hidden mb-4 shadow-md">
                              <img src={activeCommunity.coverImage} className="w-full h-full object-cover" />
                              <div className="absolute inset-0 bg-black/40 flex flex-col justify-end p-4 text-white">
                                  <h1 className="text-2xl font-bold">{activeCommunity.name}</h1>
                                  <p className="text-sm opacity-90">{activeCommunity.members} members</p>
                              </div>
                              <button className="absolute top-4 right-4 bg-white text-black px-4 py-1.5 rounded-full font-bold text-xs">Joined</button>
                          </div>
                          <div className="text-center text-gray-400 py-10">Community feed loading...</div>
                      </div>
                  );
              }
              return (
                  <div className="p-4 pb-20">
                      <div className="flex justify-between items-center mb-6">
                          <h2 className="font-bold text-lg text-gray-900">Your Communities</h2>
                          <button className="text-[#800020] text-sm font-bold flex items-center gap-1"><PlusIcon className="w-4 h-4" /> Create</button>
                      </div>
                      <div className="space-y-4">
                          {communities.map(comm => (
                              <div key={comm.id} onClick={() => setActiveCommunity(comm)} className="flex items-center gap-4 bg-white p-3 rounded-xl border border-gray-100 shadow-sm cursor-pointer">
                                  <div className="w-16 h-16 rounded-lg bg-gray-200 overflow-hidden flex-shrink-0"><img src={comm.coverImage} className="w-full h-full object-cover" /></div>
                                  <div className="flex-1"><h3 className="font-bold text-base text-gray-900">{comm.name}</h3><p className="text-xs text-gray-500">{comm.members} members</p></div>
                                  <button className="bg-blue-50 text-blue-600 px-3 py-1.5 rounded-full text-xs font-bold">Join</button>
                              </div>
                          ))}
                      </div>
                  </div>
              );

          case 'we_care':
              return (
                  <div className="p-4 pb-20 h-full flex flex-col">
                      <div className="bg-green-50 p-6 rounded-2xl mb-6 text-center">
                          <HandHeartIcon className="w-12 h-12 text-green-600 mx-auto mb-2" />
                          <h2 className="font-bold text-xl text-green-800">We Care</h2>
                          <p className="text-sm text-green-700 mt-1">Reliable health answers.</p>
                      </div>
                      <div className="relative mb-6">
                          <input 
                              value={weCareQuery}
                              onChange={(e) => setWeCareQuery(e.target.value)}
                              placeholder="Ask a health question..."
                              className="w-full bg-gray-100 border border-gray-200 rounded-xl px-4 py-3 pl-10 focus:outline-none text-black"
                              onKeyDown={(e) => e.key === 'Enter' && handleWeCareSearch()}
                          />
                          <SearchIcon className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                      </div>
                      {loadingWeCare && <div className="text-center text-gray-400">Searching...</div>}
                      {weCareResult && !loadingWeCare && (
                          <div className="bg-white border border-gray-200 rounded-xl p-6 shadow-sm">
                              <h3 className="font-bold text-lg mb-2 text-gray-900">{weCareResult.question}</h3>
                              <p className="text-gray-800 leading-relaxed">{weCareResult.summary}</p>
                          </div>
                      )}
                  </div>
              );

          default:
              return (
                  <div className="pb-28 no-scrollbar bg-[#f2f2f2] p-2">
                     {loading && <div className="text-center py-10 text-gray-400">Loading {activeTab}...</div>}
                     <div className="columns-2 gap-2 space-y-2">
                         {!loading && discoverPosts.length === 0 && (
                             <div className="col-span-2 text-center text-gray-400 py-10">No posts found for {activeTab}</div>
                         )}
                         {discoverPosts.map((post, i) => (
                             <div 
                               key={post.id} 
                               className="break-inside-avoid bg-white rounded-lg overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.1)] cursor-pointer hover:shadow-md transition-shadow"
                               onClick={() => handlePostClick(i)}
                             >
                                 <div className="w-full bg-gray-200">
                                     <video src={post.videoUrl} className="w-full h-auto object-cover block" muted />
                                 </div>
                                 <div className="p-2.5">
                                     <h3 className="font-medium text-sm text-gray-900 leading-snug line-clamp-2 mb-2">{post.description}</h3>
                                     <div className="flex items-center justify-between">
                                         <div className="flex items-center gap-1.5 min-w-0">
                                             <img src={post.avatar} className="w-4 h-4 rounded-full border border-gray-100 flex-shrink-0" />
                                             <span className="text-[10px] text-gray-500 truncate">{post.username}</span>
                                         </div>
                                         <div className="flex items-center gap-0.5 flex-shrink-0">
                                             <HeartIcon className="w-3 h-3 text-gray-400" />
                                             <span className="text-[10px] text-gray-500">{post.likes}</span>
                                         </div>
                                     </div>
                                 </div>
                             </div>
                         ))}
                     </div>
                  </div>
              );
      }
  };

  return (
    <div className="h-full w-full bg-white flex flex-col font-sans overflow-hidden">
      
      {/* Search Header */}
      <div className="bg-white sticky top-0 z-20 pt-2 shadow-sm">
         <div className="px-4 pb-2 flex items-center justify-between gap-4">
             <button onClick={onNavigateToMap} className="text-gray-600 hover:text-black transition-colors">
                 <MapIcon className="w-6 h-6" />
             </button>
             
             {/* Interactive Center Tabs */}
             <div className="flex gap-6 text-base font-bold text-gray-400">
                 <button 
                    onClick={() => setHeaderTab('flows')}
                    className={headerTab === 'flows' ? 'text-black scale-105 transition-transform border-b-2 border-black pb-1' : 'hover:text-gray-600'}
                 >
                    Flows
                 </button>
                 <button 
                    onClick={() => setHeaderTab('nearby')}
                    className={headerTab === 'nearby' ? 'text-black scale-105 transition-transform border-b-2 border-black pb-1' : 'hover:text-gray-600'}
                 >
                    Nearby
                 </button>
             </div>
             
             <button className="text-gray-600 hover:text-black">
                 <SearchIcon className="w-6 h-6" />
             </button>
         </div>

         {/* Secondary Pill Tabs - Hide if Nearby is active */}
         {headerTab === 'flows' && (
             <div className="flex overflow-x-auto no-scrollbar px-4 pb-3 gap-2 mt-1">
                 {TABS.map(tab => (
                     <button 
                        key={tab.id}
                        onClick={() => handleTabChange(tab.id)}
                        className={`px-3 py-1 text-xs font-medium rounded-full whitespace-nowrap transition-colors border ${activeTab === tab.id ? 'bg-[#f5f5f5] border-transparent text-black font-bold' : 'bg-transparent border-gray-200 text-gray-500'}`}
                     >
                         {tab.label}
                     </button>
                 ))}
             </div>
         )}
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar bg-white">
         {renderContent()}
      </div>

      {/* FULL SCREEN FEED OVERLAY */}
      {activePostIndex !== null && (
          <div className="fixed inset-0 z-50 bg-black animate-in fade-in zoom-in-95 duration-200">
              <Feed 
                posts={headerTab === 'nearby' ? nearbyPosts : discoverPosts} 
                initialIndex={activePostIndex}
                toggleLike={(id) => { /* Sync back to state */ }}
                openComments={() => {}}
                openShare={() => {}}
                onBack={closeFullScreen}
              />
          </div>
      )}
    </div>
  );
};
