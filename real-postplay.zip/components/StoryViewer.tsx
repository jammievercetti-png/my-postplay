
import React, { useEffect, useState, useRef } from 'react';
import { Story } from '../types';
import { XIcon, HeartIcon, SendIcon } from './Icons';

interface StoryViewerProps {
  stories: Story[];
  initialIndex: number;
  onClose: () => void;
}

const QUICK_REACTIONS = ['🔥', '😂', '😍', '😢', '👏', '🎉'];

export const StoryViewer: React.FC<StoryViewerProps> = ({ stories, initialIndex, onClose }) => {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  
  // Swipe State
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);
  const touchEndY = useRef<number | null>(null);

  const currentStory = stories[currentIndex];

  useEffect(() => {
    setProgress(0);
  }, [currentIndex]);

  useEffect(() => {
    if (isPaused) return;

    const duration = currentStory.duration * 1000;
    const intervalTime = 50;
    const step = (intervalTime / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNext();
          return 0;
        }
        return prev + step;
      });
    }, intervalTime);

    return () => clearInterval(timer);
  }, [currentIndex, isPaused, currentStory]);

  const handleNext = () => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      onClose();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    } else {
      setProgress(0);
    }
  };

  const handleSendReply = () => {
      if (!replyText.trim()) return;
      // In production: await cmd.chat.send_text(currentStory.username, replyText);
      console.log(`Sent reply to ${currentStory.username}: ${replyText}`);
      setReplyText('');
      setIsPaused(false);
      alert('Reply sent!');
  };

  const handleReaction = (emoji: string) => {
      // In production: await cmd.chat.send_reaction(currentStory.id, emoji);
      console.log(`Sent reaction: ${emoji}`);
      // Show visual feedback (simple toast simulation)
      const el = document.createElement('div');
      el.innerText = emoji;
      el.style.position = 'absolute';
      el.style.left = '50%';
      el.style.bottom = '150px';
      el.style.fontSize = '4rem';
      el.style.transform = 'translate(-50%, 0)';
      el.style.animation = 'float 1s ease-out forwards';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 1000);
  };

  // --- SWIPE HANDLERS ---
  const onTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
    touchStartY.current = e.targetTouches[0].clientY;
    setIsPaused(true);
  };

  const onTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
    touchEndY.current = e.targetTouches[0].clientY;
  };

  const onTouchEnd = () => {
    setIsPaused(false);
    if (!touchStartX.current || !touchEndX.current || !touchStartY.current || !touchEndY.current) return;

    const distNamesX = touchStartX.current - touchEndX.current;
    const distNamesY = touchStartY.current - touchEndY.current;
    const minSwipeDistance = 50;

    // Vertical Swipe (Down) -> Close
    if (distNamesY < -100) { // Dragged down significantly
        onClose();
        return;
    }

    // Horizontal Swipes
    if (Math.abs(distNamesX) > Math.abs(distNamesY)) {
        if (distNamesX > minSwipeDistance) {
          handleNext(); // Swipe Left
        } else if (distNamesX < -minSwipeDistance) {
          handlePrev(); // Swipe Right
        }
    }
    
    // Reset
    touchStartX.current = null;
    touchEndX.current = null;
    touchStartY.current = null;
    touchEndY.current = null;
  };

  return (
    <div className="fixed inset-0 z-[70] bg-black flex flex-col animate-slide-up origin-bottom">
      {/* Background Blur */}
      <div className="absolute inset-0 bg-gray-900">
          <img src={currentStory.mediaUrl} className="w-full h-full object-cover blur-3xl opacity-30" />
      </div>
      
      {/* Main Content */}
      <div className="relative z-10 w-full h-full flex flex-col">
        {/* Progress Bars */}
        <div className="flex gap-1 p-2 pt-4 safe-top">
          {stories.map((story, idx) => (
            <div key={story.id} className="h-0.5 flex-1 bg-white/30 rounded-full overflow-hidden">
               <div 
                 className={`h-full bg-white transition-all duration-100 ease-linear`}
                 style={{ 
                   width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%' 
                 }}
               ></div>
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="flex justify-between items-center px-4 mt-2">
           <div className="flex items-center gap-3">
              <img src={currentStory.avatar} className="w-9 h-9 rounded-full border border-white/50" />
              <div>
                 <p className="text-white text-sm font-bold flex items-center gap-2 drop-shadow-md">
                    {currentStory.username} 
                    <span className="text-gray-300 font-normal text-xs">{Math.floor((Date.now() - currentStory.timestamp) / 3600000)}h</span>
                 </p>
                 {currentStory.isCloseFriends && (
                    <span className="bg-green-500 text-white text-[9px] px-1.5 py-0.5 rounded font-bold shadow-sm">Close Friends</span>
                 )}
              </div>
           </div>
           <div className="flex gap-4">
               <button onClick={onClose} className="p-2">
                  <XIcon className="w-6 h-6 text-white drop-shadow-md" />
               </button>
           </div>
        </div>

        {/* Media Area */}
        <div 
          className="flex-1 flex items-center justify-center relative my-2 overflow-hidden"
          onTouchStart={onTouchStart}
          onTouchMove={onTouchMove}
          onTouchEnd={onTouchEnd}
          onMouseDown={() => setIsPaused(true)}
          onMouseUp={() => setIsPaused(false)}
        >
           {/* Navigation Tap Zones */}
           <div 
             className="absolute inset-y-0 left-0 w-1/4 z-20" 
             onClick={(e) => { e.stopPropagation(); if (!touchStartX.current) handlePrev(); }}
           ></div>
           <div 
             className="absolute inset-y-0 right-0 w-1/4 z-20" 
             onClick={(e) => { e.stopPropagation(); if (!touchStartX.current) handleNext(); }}
           ></div>
           
           <img src={currentStory.mediaUrl} className="max-h-full max-w-full rounded-xl shadow-2xl" />
        </div>

        {/* Footer Actions */}
        <div className="p-4 pb-8 bg-gradient-to-t from-black via-black/50 to-transparent">
           {/* Quick Reactions */}
           <div className="flex justify-between px-2 mb-4">
               {QUICK_REACTIONS.map(emoji => (
                   <button 
                     key={emoji} 
                     onClick={() => handleReaction(emoji)}
                     className="text-2xl hover:scale-125 transition-transform active:scale-95"
                   >
                       {emoji}
                   </button>
               ))}
           </div>

           <div className="flex items-center gap-3">
              <div className="flex-1 relative">
                  <input 
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    onFocus={() => setIsPaused(true)}
                    onBlur={() => setIsPaused(false)}
                    placeholder={`Reply to ${currentStory.username}...`} 
                    className="w-full bg-transparent border border-white/40 rounded-full px-4 py-3 text-white text-sm placeholder-white/70 focus:outline-none focus:border-white focus:bg-black/40 transition-colors"
                  />
                  {replyText && (
                      <button 
                        onClick={handleSendReply}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-blue-400 font-bold text-xs"
                      >
                          Send
                      </button>
                  )}
              </div>
              <button onClick={() => handleReaction('❤️')} className="p-2 rounded-full active:bg-white/10">
                  <HeartIcon className="w-8 h-8 text-white hover:text-red-500 transition-colors drop-shadow-md" />
              </button>
              <button className="p-2 rounded-full active:bg-white/10">
                  <SendIcon className="w-7 h-7 text-white drop-shadow-md" />
              </button>
           </div>
        </div>
      </div>
    </div>
  );
};
