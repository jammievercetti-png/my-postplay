

import React from 'react';
import { AppView } from '../types';
import { HomeIcon, SearchIcon, PlusIcon, InboxIcon, UserIcon, ShopIcon, LiveIcon, OrbIcon, FeatherIcon } from './Icons';

interface BottomNavProps {
  currentView: AppView;
  onChangeView: (view: AppView) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentView, onChangeView }) => {
  const isDark = currentView === AppView.FEED || currentView === AppView.LIVE || currentView === AppView.ECHO_FEED;
  
  // Floating Item
  const NavItem = ({ view, icon: Icon, label }: { view: AppView, icon: any, label?: string }) => {
    const active = currentView === view;
    return (
      <button 
        onClick={() => onChangeView(view)}
        className={`flex flex-col items-center justify-center w-12 h-12 transition-all duration-300 rounded-full ${active ? 'bg-white/20 shadow-[0_0_15px_rgba(255,255,255,0.3)] text-white scale-110' : 'text-white/60 hover:text-white'}`}
      >
        <Icon active={active} className="w-6 h-6" />
      </button>
    );
  };

  // Text Nav Item for Words
  const TextNavItem = ({ view, label }: { view: AppView, label: string }) => {
     const active = currentView === view;
     return (
        <button 
          onClick={() => onChangeView(view)}
          className={`relative px-3 py-2 text-sm font-bold transition-all ${active ? 'text-white scale-105' : 'text-white/60 hover:text-white'}`}
        >
           {label}
           {active && <div className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-white rounded-full"></div>}
        </button>
     );
  };

  return (
    <div className="fixed bottom-6 left-0 right-0 z-50 flex justify-center pointer-events-none">
        {/* Floating Glass Dock */}
        <div className="glass-capsule pointer-events-auto flex items-center justify-between px-4 py-1 h-16 w-[95%] max-w-[400px] rounded-[30px] animate-slide-up">
            
            <TextNavItem view={AppView.FEED} label="Home" />
            <TextNavItem view={AppView.DISCOVER} label="Flows" />
            
            {/* Central Create Orb */}
            <div className="relative -top-5 mx-2">
                <button 
                    onClick={() => onChangeView(AppView.UPLOAD)} 
                    className="w-14 h-14 rounded-full bg-gradient-to-tr from-[#800020] to-[#a01030] flex items-center justify-center shadow-[0_4px_20px_rgba(128,0,32,0.5)] border-4 border-black/50 hover:scale-105 transition-transform"
                >
                    <PlusIcon className="w-7 h-7 text-white" />
                </button>
            </div>

            <TextNavItem view={AppView.INBOX} label="Messages" />
            
            <button 
              onClick={() => onChangeView(AppView.PROFILE)}
              className={`flex flex-col items-center justify-center w-10 h-10 rounded-full transition-all ${currentView === AppView.PROFILE ? 'text-white' : 'text-white/60'}`}
            >
              <UserIcon active={currentView === AppView.PROFILE} className="w-6 h-6" />
            </button>
        </div>
    </div>
  );
};

interface TopNavFeedProps {
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  feedTab: 'live' | 'following' | 'foryou';
  setFeedTab: (tab: 'live' | 'following' | 'foryou') => void;
}

export const TopNavFeed: React.FC<TopNavFeedProps> = ({ currentView, onChangeView, feedTab, setFeedTab }) => {
  return (
    <div className="fixed top-0 left-0 right-0 z-40 flex items-center justify-between px-4 pt-6 pb-4 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
       {/* Echo Toggle (Top Left) */}
       <div className="pointer-events-auto">
           <button 
             onClick={() => onChangeView(currentView === AppView.ECHO_FEED ? AppView.FEED : AppView.ECHO_FEED)}
             className={`w-10 h-10 rounded-full flex items-center justify-center transition-all ${currentView === AppView.ECHO_FEED ? 'bg-white text-black shadow-lg scale-110' : 'bg-black/30 text-white border border-white/20'}`}
           >
               <FeatherIcon className="w-5 h-5" />
           </button>
       </div>

       {/* Center Tabs (Hidden if on Echo Feed) */}
       {currentView !== AppView.ECHO_FEED && (
           <div className="flex gap-4 pointer-events-auto absolute left-1/2 transform -translate-x-1/2">
             <button 
               onClick={() => { onChangeView(AppView.FEED); setFeedTab('live'); }}
               className={`text-base font-bold transition-all drop-shadow-md ${feedTab === 'live' ? 'text-white scale-110' : 'text-white/60 hover:text-white'}`}
             >
               Live
             </button>
             <div className="w-px h-4 bg-white/20 self-center"></div>
             <button 
               onClick={() => { onChangeView(AppView.FEED); setFeedTab('following'); }}
               className={`text-base font-bold transition-all drop-shadow-md ${feedTab === 'following' ? 'text-white scale-110' : 'text-white/60 hover:text-white'}`}
             >
               Following
             </button>
             <div className="w-px h-4 bg-white/20 self-center"></div>
             <button 
               onClick={() => { onChangeView(AppView.FEED); setFeedTab('foryou'); }}
               className={`text-base font-bold transition-all drop-shadow-md ${feedTab === 'foryou' ? 'text-white scale-110' : 'text-white/60 hover:text-white'}`}
             >
               For You
             </button>
           </div>
       )}

       {/* Spacer for Search/Settings (Top Right) */}
       <div className="w-10"></div>
    </div>
  );
};
