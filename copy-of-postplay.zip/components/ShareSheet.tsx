
import React from 'react';
import { 
  WhatsAppIcon, InstagramIcon, LinkIcon, 
  SendIcon, RepostIcon
} from './Icons';

interface ShareSheetProps {
  onClose: () => void;
  onAction: (action: string) => void;
}

const SocialButton: React.FC<{ icon: React.ReactNode; label: string; color?: string; onClick: () => void }> = ({ icon, label, color, onClick }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 min-w-[70px]">
    <div className={`w-12 h-12 rounded-full flex items-center justify-center text-white shadow-sm ${color || 'bg-gray-100'}`}>
      {icon}
    </div>
    <span className="text-[10px] text-gray-500 font-medium text-center leading-tight">{label}</span>
  </button>
);

const ActionButton: React.FC<{ icon: React.ReactNode; label: string; onClick: () => void }> = ({ icon, label, onClick }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 min-w-[70px]">
    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-700 hover:bg-gray-200 transition-colors">
      {icon}
    </div>
    <span className="text-[10px] text-gray-500 font-medium text-center leading-tight">{label}</span>
  </button>
);

const UserAvatar: React.FC<{ name: string; onClick: () => void }> = ({ name, onClick }) => (
    <button onClick={onClick} className="flex flex-col items-center gap-1.5 min-w-[64px]">
        <div className="relative">
            <img src={`https://picsum.photos/seed/${name}/100`} className="w-12 h-12 rounded-full border border-gray-100 object-cover" />
            <div className="absolute bottom-0 right-0 bg-blue-500 rounded-full p-0.5 border-2 border-white">
                <SendIcon className="w-2.5 h-2.5 text-white" />
            </div>
        </div>
        <span className="text-[10px] text-gray-600 font-medium truncate w-16 text-center">{name}</span>
    </button>
);

export const ShareSheet: React.FC<ShareSheetProps> = ({ onClose, onAction }) => {
  return (
    <div className="absolute inset-0 z-[60] flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/40 transition-opacity" onClick={onClose}></div>
      <div className="bg-white rounded-t-xl w-full relative z-10 animate-slide-up pb-8 pt-2">
        
        <div className="w-10 h-1 bg-gray-300 rounded-full mx-auto mb-4 mt-2"></div>
        
        {/* Send To Section */}
        <div className="px-4 mb-6">
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wide mb-3 px-2">Send to</h3>
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
                {['Alice', 'John', 'Sarah', 'Mike', 'Emma', 'David'].map(name => (
                    <UserAvatar key={name} name={name} onClick={() => onAction(`send_to_${name}`)} />
                ))}
            </div>
        </div>

        <div className="h-px bg-gray-100 mx-4 mb-4"></div>

        {/* Row 1: Social Apps */}
        <div className="flex gap-4 overflow-x-auto no-scrollbar px-6 mb-6 pb-2">
           <SocialButton 
             icon={<RepostIcon className="w-6 h-6 text-white" />} 
             label="Repost" 
             color="bg-yellow-500"
             onClick={() => onAction('repost')} 
           />
           <SocialButton 
             icon={<WhatsAppIcon className="w-7 h-7" />} 
             label="WhatsApp" 
             color="bg-green-500"
             onClick={() => onAction('whatsapp')} 
           />
           <SocialButton 
             icon={<InstagramIcon className="w-7 h-7 text-white" />} 
             label="Stories" 
             color="bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600"
             onClick={() => onAction('instagram')} 
           />
           <SocialButton 
             icon={<div className="font-bold text-xl">SMS</div>} 
             label="Message" 
             color="bg-green-400"
             onClick={() => onAction('sms')} 
           />
           <SocialButton 
             icon={<LinkIcon className="w-6 h-6 text-white" />} 
             label="Copy Link" 
             color="bg-blue-500"
             onClick={() => onAction('copy')} 
           />
        </div>

        {/* Row 2: Actions */}
        <div className="flex gap-4 overflow-x-auto no-scrollbar px-6 border-t border-gray-100 pt-6">
           <ActionButton 
             icon={<div className="rotate-45 font-bold">⚠️</div>} 
             label="Report" 
             onClick={() => onAction('report')} 
           />
           <ActionButton 
             icon={<div className="font-bold">💔</div>} 
             label="Not Interested" 
             onClick={() => onAction('not_interested')} 
           />
           <ActionButton 
             icon={<div className="font-bold">⬇️</div>} 
             label="Save Video" 
             onClick={() => onAction('save')} 
           />
           <ActionButton 
             icon={<div className="font-bold text-sm">👯</div>} 
             label="Duet" 
             onClick={() => onAction('duet')} 
           />
           <ActionButton 
             icon={<div className="font-bold text-sm">🧵</div>} 
             label="Stitch" 
             onClick={() => onAction('stitch')} 
           />
           <ActionButton 
             icon={<div className="font-bold text-sm">🔀</div>} 
             label="Remix" 
             onClick={() => onAction('remix')} 
           />
        </div>
        
        <button onClick={onClose} className="w-full mt-6 py-3 border-t border-gray-100 text-sm font-semibold text-gray-500 bg-gray-50 hover:bg-gray-100">
           Cancel
        </button>
      </div>
    </div>
  );
};
