
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { SearchIcon, BagIcon, FlashIcon, PlusIcon, XIcon } from '../components/Icons';
import { getCurrentUser } from '../services/auth';
import { cmd } from '../services/commands';

const MOCK_PRODUCTS: Product[] = [
  { id: '1', name: 'Viral Lip Gloss', price: 12.99, originalPrice: 24.99, image: 'https://picsum.photos/seed/makeup/200', sales: 12000, rating: 4.8, seller: 'BeautyCo' },
  { id: '2', name: 'LED Ring Light', price: 35.00, image: 'https://picsum.photos/seed/tech/200', sales: 5400, rating: 4.5, seller: 'TechGadgets' },
];

export const Shop: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showUpload, setShowUpload] = useState(false);
  const user = getCurrentUser();

  // Upload Form State
  const [prodName, setProdName] = useState('');
  const [prodPrice, setProdPrice] = useState('');
  const [prodCat, setProdCat] = useState('Fashion');

  const handleUpload = async () => {
      if (!prodName || !prodPrice) return;
      try {
          await cmd.product.upload({
              name: prodName,
              price: parseFloat(prodPrice),
              image: `https://picsum.photos/seed/${prodName}/200`, // Auto-generate mock image for demo
              category: prodCat
          });
          alert('Product Listed!');
          setShowUpload(false);
      } catch (e) {
          alert('Failed to list product');
      }
  };

  return (
    <div className="h-full w-full bg-gray-50 flex flex-col font-sans overflow-hidden relative">
      
      {/* Header */}
      <div className="bg-white p-4 sticky top-0 z-10 shadow-sm">
         <div className="flex justify-between items-center mb-4">
             <h1 className="text-xl font-black text-[#800020]">PostPlays Shop</h1>
             {user?.isBrand && (
                 <button onClick={() => setShowUpload(true)} className="bg-black text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1">
                     <PlusIcon className="w-4 h-4" /> Sell
                 </button>
             )}
         </div>
         <div className="flex gap-3">
            <div className="flex-1 bg-gray-100 rounded-lg flex items-center px-3 py-2">
               <SearchIcon className="w-4 h-4 text-gray-400" />
               <input 
                 className="flex-1 bg-transparent ml-2 text-sm focus:outline-none text-black"
                 placeholder="Search products..."
                 value={searchTerm}
                 onChange={(e) => setSearchTerm(e.target.value)}
               />
            </div>
            <button className="flex items-center gap-1 bg-gray-100 px-3 py-2 rounded-lg font-medium text-xs text-black">
               <BagIcon className="w-4 h-4" />
            </button>
         </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 pb-20">
         {/* Flash Sale Banner */}
         <div className="bg-gradient-to-r from-orange-500 to-[#800020] rounded-xl p-4 mb-6 text-white relative overflow-hidden shadow-lg">
            <div className="relative z-10">
               <div className="flex items-center gap-2 mb-1">
                  <FlashIcon active className="text-yellow-300 w-5 h-5" />
                  <h3 className="font-bold uppercase tracking-wider text-sm">Flash Sale</h3>
               </div>
               <h2 className="text-xl font-bold mb-2">Up to 70% OFF</h2>
               <button className="bg-white text-[#800020] px-4 py-1.5 rounded-full text-xs font-bold">Shop Now</button>
            </div>
         </div>

         {/* Product Grid */}
         <h3 className="font-bold text-lg mb-3 text-black">Recommended</h3>
         <div className="grid grid-cols-2 gap-3">
            {MOCK_PRODUCTS.map(product => (
               <div key={product.id} className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow">
                  <div className="relative aspect-square bg-gray-200">
                     <img src={product.image} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-2">
                     <h4 className="font-medium text-xs line-clamp-2 h-8 leading-4 mb-1 text-black">{product.name}</h4>
                     <div className="flex items-center gap-1 mb-1">
                        <span className="text-[#800020] font-bold text-sm">${product.price}</span>
                     </div>
                     <div className="mt-2 flex items-center gap-1">
                        <span className="text-[9px] bg-gray-100 text-gray-600 px-1 rounded">{product.seller}</span>
                     </div>
                  </div>
               </div>
            ))}
         </div>
      </div>

      {/* Upload Modal */}
      {showUpload && (
          <div className="absolute inset-0 z-50 bg-black/50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl w-full max-w-sm p-6 animate-popup">
                  <div className="flex justify-between items-center mb-4">
                      <h2 className="font-bold text-lg text-black">List Product</h2>
                      <button onClick={() => setShowUpload(false)}><XIcon className="w-6 h-6 text-gray-500" /></button>
                  </div>
                  <div className="space-y-4">
                      <input value={prodName} onChange={e => setProdName(e.target.value)} placeholder="Product Name" className="w-full p-3 bg-gray-50 rounded-lg text-black text-sm border border-gray-200" />
                      <input value={prodPrice} onChange={e => setProdPrice(e.target.value)} placeholder="Price ($)" type="number" className="w-full p-3 bg-gray-50 rounded-lg text-black text-sm border border-gray-200" />
                      <select value={prodCat} onChange={e => setProdCat(e.target.value)} className="w-full p-3 bg-gray-50 rounded-lg text-black text-sm border border-gray-200">
                          <option>Fashion</option><option>Tech</option><option>Beauty</option>
                      </select>
                      <button onClick={handleUpload} className="w-full bg-[#800020] text-white py-3 rounded-lg font-bold shadow-md">Upload Listing</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
