
import React, { useState, useEffect } from 'react';
import { Chat, Message, Story, Note, Place } from '../types';
import { 
  ChevronLeftIcon, SearchIcon, PhoneIcon, VideoCallIcon, 
  PlusIcon, BlockIcon, FlagIcon, MapPinIcon, MoreHorizontalIcon
} from '../components/Icons';
import { blockUser, isBlocked } from '../services/social';
import { getPopularPlaces } from '../services/places';

// --- MOCK DATA ---
const MOCK_STORIES: Story[] = [
  { id: '1', username: 'alice', avatar: 'https://picsum.photos/seed/alice/100', isSeen: false, mediaUrl: 'https://picsum.photos/seed/alice_story/800/1400', type: 'image', duration: 5, timestamp: Date.now() - 3600000 },
  { id: '2', username: 'john_d', avatar: 'https://picsum.photos/seed/john/100', isSeen: false, mediaUrl: 'https://picsum.photos/seed/john_story/800/1400', type: 'video', duration: 15, timestamp: Date.now() - 7200000 },
];

const MOCK_NOTES: Note[] = [
  { id: 'n1', userId: 'user_2', username: 'john_d', avatar: 'https://picsum.photos/seed/john/50', text: 'Coffee time ☕️', timestamp: Date.now() },
  { id: 'n2', userId: 'user_3', username: 'sarah', avatar: 'https://picsum.photos/seed/sarah/50', text: 'Loving the new album! 🎶', timestamp: Date.now() },
];

const MOCK_CHATS: Chat[] = [
  {
    id: '1', userId: 'user_1', username: 'Alice Smith', avatar: 'https://picsum.photos/seed/alice/50', lastMessage: 'Are we still going to the beach?', unread: 2, timestamp: Date.now() - 300000, isOnline: true,
    messages: [ { id: 'm1', text: 'Hey!', sender: 'them', timestamp: Date.now() - 100000, type: 'text', status: 'read' } ]
  },
  {
    id: '2', userId: 'user_2', username: 'John Doe', avatar: 'https://picsum.photos/seed/john/50', lastMessage: '🎤 Voice Message (0:15)', unread: 0, timestamp: Date.now() - 3600000,
    messages: [ { id: 'm3', text: '', sender: 'me', timestamp: Date.now() - 360000, type: 'audio', status: 'read' } ]
  }
];

const NotesRail: React.FC<{ notes: Note[] }> = ({ notes }) => (
    <div className="w-full overflow-x-auto no-scrollbar py-4 pl-4 flex gap-4 border-b border-gray-100">
        <div className="flex flex-col items-center gap-1 cursor-pointer min-w-[70px]">
             <div className="relative">
                 <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center relative">
                     <img src="https://picsum.photos/seed/me/100" className="w-full h-full rounded-full opacity-50" />
                     <PlusIcon className="w-6 h-6 absolute text-black" />
                 </div>
                 <div className="absolute -top-2 left-0 right-0 bg-gray-100 text-[10px] text-gray-500 px-2 py-1 rounded-full text-center truncate shadow-sm">
                    Share a thought
                 </div>
             </div>
             <span className="text-[11px] text-gray-400">Your Note</span>
        </div>
        
        {notes.map(note => (
            <div key={note.id} className="flex flex-col items-center gap-1 cursor-pointer min-w-[70px]">
                <div className="relative">
                    <img src={note.avatar} className="w-16 h-16 rounded-full border border-gray-200 p-0.5" />
                    <div className="absolute -top-4 left-[-10px] right-[-10px] bg-white border border-gray-200 text-[11px] text-gray-800 px-2 py-2 rounded-2xl text-center shadow-sm z-10 leading-tight">
                        {note.text}
                    </div>
                </div>
                <span className="text-[11px] text-gray-500 font-medium">{note.username}</span>
            </div>
        ))}
    </div>
);

export const Inbox: React.FC = () => {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [chats, setChats] = useState<Chat[]>(MOCK_CHATS);

  if (!selectedChatId) {
    return (
      <div className="h-full w-full bg-white text-black flex flex-col font-sans">
        <div className="p-4 flex items-center justify-between bg-white border-b border-gray-100 z-10 sticky top-0">
           <h1 className="text-xl font-bold tracking-tight">Inbox</h1>
           <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
              <SearchIcon className="w-4 h-4 text-gray-500" />
           </div>
        </div>

        <div className="flex-1 overflow-y-auto pb-20">
           <NotesRail notes={MOCK_NOTES} />
           
           <div className="px-2 mt-4">
             <div className="flex justify-between items-center px-4 mb-2">
                 <div className="text-xs font-bold text-gray-400 uppercase tracking-wider">Messages</div>
                 <div className="text-xs text-blue-500 font-bold cursor-pointer">Requests</div>
             </div>
             
             {chats.map(chat => (
               <div key={chat.id} onClick={() => setSelectedChatId(chat.id)} className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors cursor-pointer rounded-xl mx-2">
                  <div className="relative">
                     <div className="w-14 h-14 rounded-full overflow-hidden border border-gray-100"><img src={chat.avatar} className="w-full h-full object-cover" /></div>
                     {chat.isOnline && <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 rounded-full border-2 border-white"></div>}
                  </div>
                  <div className="flex-1 min-w-0">
                     <div className="flex justify-between items-baseline mb-1">
                        <h3 className="font-semibold text-sm text-gray-900">{chat.username}</h3>
                        <span className="text-[11px] text-gray-400">10:42 AM</span>
                     </div>
                     <p className={`text-xs truncate ${chat.unread > 0 ? 'text-black font-bold' : 'text-gray-500'}`}>{chat.lastMessage}</p>
                  </div>
                  {chat.unread > 0 && <div className="w-5 h-5 rounded-full bg-[#fe2c55] flex items-center justify-center text-[10px] text-white font-bold shadow-sm">{chat.unread}</div>}
               </div>
             ))}
           </div>
        </div>
      </div>
    );
  }

  const activeChat = chats.find(c => c.id === selectedChatId)!;
  return <ChatDetail chat={activeChat} onBack={() => setSelectedChatId(null)} />;
};

const ChatDetail: React.FC<{ chat: Chat; onBack: () => void }> = ({ chat, onBack }) => {
  const [messages, setMessages] = useState<Message[]>(chat.messages);
  const [inputText, setInputText] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [isUserBlocked, setIsUserBlocked] = useState(false);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  const [showLocationPicker, setShowLocationPicker] = useState(false);

  useEffect(() => {
      setIsUserBlocked(isBlocked(chat.userId));
  }, [chat.userId]);

  const handleSend = () => {
    if (!inputText.trim() || isUserBlocked) return;
    const newMsg: Message = { id: Date.now().toString(), text: inputText, sender: 'me', timestamp: Date.now(), type: 'text', status: 'sent' };
    setMessages([...messages, newMsg]);
    setInputText('');
  };

  const handleSendLocation = (place: Place) => {
     const newMsg: Message = {
         id: Date.now().toString(),
         text: 'Shared a location',
         sender: 'me',
         timestamp: Date.now(),
         type: 'location',
         status: 'sent',
         locationData: place
     };
     setMessages([...messages, newMsg]);
     setShowLocationPicker(false);
     setShowPlusMenu(false);
  };

  const handleBlock = () => {
      blockUser(chat.userId);
      setIsUserBlocked(true);
      setShowSettings(false);
  };

  return (
    <div className="h-full w-full bg-white flex flex-col relative">
      {/* Header */}
      <div className="h-14 bg-white border-b border-gray-100 flex items-center px-4 justify-between z-10 shadow-sm">
         <div className="flex items-center gap-3">
            <button onClick={onBack}><ChevronLeftIcon className="text-black" /></button>
            <div className="w-8 h-8 rounded-full overflow-hidden bg-gray-100"><img src={chat.avatar} className="w-full h-full object-cover" /></div>
            <div><h3 className="font-bold text-black text-sm">{chat.username}</h3></div>
         </div>
         <div className="flex gap-4 text-black items-center">
            <button><VideoCallIcon className="w-6 h-6" /></button>
            <button onClick={() => setShowSettings(true)}><MoreHorizontalIcon className="w-6 h-6" /></button>
         </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2 bg-white">
         {isUserBlocked && (
             <div className="bg-red-50 text-red-600 text-xs text-center p-2 rounded mb-4">
                 You have blocked this user. You cannot send or receive messages.
             </div>
         )}
         {messages.map(msg => (
           <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'} mb-4`}>
              {msg.type === 'location' && msg.locationData ? (
                  // Location Message Bubble
                  <div className="max-w-[260px] bg-gray-100 rounded-xl overflow-hidden shadow-sm border border-gray-200">
                      <div className="h-32 bg-gray-200 relative">
                          <img src={msg.locationData.image} className="w-full h-full object-cover" />
                          <div className="absolute inset-0 flex items-center justify-center">
                              <MapPinIcon className="w-8 h-8 text-red-500 drop-shadow-md" />
                          </div>
                      </div>
                      <div className="p-3 bg-white">
                          <h4 className="font-bold text-sm truncate">{msg.locationData.name}</h4>
                          <p className="text-xs text-gray-500 truncate">{msg.locationData.address}</p>
                      </div>
                  </div>
              ) : (
                  // Text Message Bubble
                  <div className={`max-w-[260px] px-3 py-2 rounded-2xl text-sm leading-snug shadow-sm ${msg.sender === 'me' ? 'bg-blue-500 text-white rounded-br-none' : 'bg-gray-100 text-black rounded-bl-none'}`}>
                     {msg.text}
                  </div>
              )}
           </div>
         ))}
      </div>

      {/* Input Area */}
      {!isUserBlocked ? (
          <div className="p-3 bg-white flex items-center gap-3 pb-8 border-t border-gray-100 relative z-20">
             <button 
                onClick={() => setShowPlusMenu(!showPlusMenu)}
                className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${showPlusMenu ? 'bg-black text-white' : 'bg-gray-100 text-blue-500'}`}
             >
                <PlusIcon className={`w-5 h-5 transition-transform ${showPlusMenu ? 'rotate-45' : ''}`} />
             </button>
             
             <div className="flex-1 bg-gray-100 rounded-full flex items-center px-4 py-2">
                <input className="flex-1 bg-transparent text-black text-sm focus:outline-none" placeholder="Message..." value={inputText} onChange={(e) => setInputText(e.target.value)} />
             </div>
             <button onClick={handleSend} className="text-blue-500 font-bold text-sm">Send</button>
          </div>
      ) : (
          <div className="p-4 pb-8 border-t border-gray-100 text-center text-gray-400 text-sm font-bold">Messaging unavailable</div>
      )}

      {/* Plus Menu (Attachments) */}
      {showPlusMenu && (
          <div className="p-4 bg-gray-50 grid grid-cols-4 gap-4 animate-slide-up pb-8 border-t border-gray-200">
             <button onClick={() => setShowLocationPicker(true)} className="flex flex-col items-center gap-2">
                 <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                    <MapPinIcon className="w-6 h-6" />
                 </div>
                 <span className="text-xs font-medium text-gray-600">Location</span>
             </button>
             {/* Other placeholders */}
             <div className="flex flex-col items-center gap-2 opacity-50">
                 <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">📷</div>
                 <span className="text-xs font-medium">Camera</span>
             </div>
          </div>
      )}

      {/* Location Picker Modal */}
      {showLocationPicker && (
          <div className="absolute inset-0 z-50 bg-white flex flex-col animate-slide-up">
              <div className="p-4 border-b border-gray-100 flex items-center gap-3">
                  <button onClick={() => setShowLocationPicker(false)}><ChevronLeftIcon className="w-6 h-6" /></button>
                  <h3 className="font-bold">Share Location</h3>
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg text-blue-500 font-bold cursor-pointer">
                      <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center"><MapPinIcon className="w-5 h-5" /></div>
                      Current Location
                  </div>
                  <div className="px-2 pt-2 text-xs font-bold text-gray-400 uppercase">Nearby Places</div>
                  {getPopularPlaces().map(place => (
                      <div key={place.id} onClick={() => handleSendLocation(place)} className="flex items-center gap-3 p-3 hover:bg-gray-50 rounded-lg cursor-pointer border-b border-gray-50">
                          <img src={place.image} className="w-12 h-12 rounded-lg object-cover bg-gray-200" />
                          <div className="flex-1">
                              <div className="font-bold text-sm">{place.name}</div>
                              <div className="text-xs text-gray-500">{place.address}</div>
                          </div>
                      </div>
                  ))}
              </div>
          </div>
      )}

      {/* Chat Settings Drawer */}
      {showSettings && (
          <div className="absolute inset-0 z-50">
             <div className="absolute inset-0 bg-black/50" onClick={() => setShowSettings(false)}></div>
             <div className="absolute bottom-0 left-0 right-0 bg-white rounded-t-xl animate-slide-up p-4 pb-8">
                 <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-6"></div>
                 <button onClick={handleBlock} className="w-full flex items-center gap-3 p-4 text-red-600 font-bold border-b border-gray-100">
                     <BlockIcon className="w-5 h-5" /> Block {chat.username}
                 </button>
                 <button className="w-full flex items-center gap-3 p-4 text-gray-700 font-medium">
                     <FlagIcon className="w-5 h-5" /> Report Content
                 </button>
             </div>
          </div>
      )}
    </div>
  );
};
