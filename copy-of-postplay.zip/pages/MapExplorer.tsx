
import React, { useState } from 'react';
import { ChevronLeftIcon, SearchIcon, MapPinIcon, NavigationIcon, CompassIcon, InfoIcon, XIcon, UserIcon } from '../components/Icons';
import { Place } from '../types';
import { getPopularPlaces, searchPlaces } from '../services/places';

interface MapExplorerProps {
  onBack: () => void;
}

// Simulated Friends Data
const FRIENDS_LOCATIONS = [
    { id: 'f1', name: 'Sarah', lat: 45, lng: 55, avatar: 'https://picsum.photos/seed/sarah/50' },
    { id: 'f2', name: 'Mike', lat: 65, lng: 35, avatar: 'https://picsum.photos/seed/mike/50' },
];

export const MapExplorer: React.FC<MapExplorerProps> = ({ onBack }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedPlace, setSelectedPlace] = useState<Place | null>(null);
  
  const places = searchQuery ? searchPlaces(searchQuery) : getPopularPlaces();

  return (
    <div className="h-full w-full bg-gray-100 flex flex-col font-sans relative overflow-hidden">
      
      {/* Floating Header */}
      <div className="absolute top-0 left-0 right-0 z-30 p-4 pt-4 bg-gradient-to-b from-black/50 to-transparent">
         <div className="flex gap-3">
             <button onClick={onBack} className="w-10 h-10 rounded-full bg-white/90 backdrop-blur-md shadow-md flex items-center justify-center">
                 <ChevronLeftIcon className="w-6 h-6 text-black" />
             </button>
             <div className="flex-1 bg-white/90 backdrop-blur-md rounded-full shadow-md flex items-center px-4">
                 <SearchIcon className="w-4 h-4 text-gray-400" />
                 <input 
                    className="flex-1 bg-transparent ml-2 text-sm focus:outline-none h-10 text-black"
                    placeholder="Search places & friends..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                 />
             </div>
         </div>
      </div>

      {/* Map Area */}
      <div className="flex-1 relative bg-[#e5e3df] overflow-hidden cursor-grab active:cursor-grabbing">
         {/* Map Background */}
         <div 
            className="absolute inset-0 w-[200%] h-[200%] top-[-50%] left-[-50%] opacity-80"
            style={{ 
                backgroundImage: 'url("https://upload.wikimedia.org/wikipedia/commons/e/ec/World_map_blank_without_borders.svg")',
                backgroundSize: 'cover',
                filter: 'grayscale(0.2) contrast(1.1)'
            }}
         ></div>
         
         {/* Friend Bubbles (Live Location) */}
         {FRIENDS_LOCATIONS.map(friend => (
             <div key={friend.id} className="absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center animate-float z-20" style={{ top: `${friend.lat}%`, left: `${friend.lng}%` }}>
                 <div className="relative">
                     <img src={friend.avatar} className="w-10 h-10 rounded-full border-2 border-white shadow-lg" />
                     <div className="absolute -bottom-1 -right-1 bg-green-500 w-3 h-3 rounded-full border border-white"></div>
                 </div>
                 <span className="bg-black/50 text-white text-[9px] px-1.5 py-0.5 rounded-full mt-1 backdrop-blur-sm">{friend.name}</span>
             </div>
         ))}

         {/* Place Pins */}
         {places.map(place => (
             <button
                key={place.id}
                onClick={() => setSelectedPlace(place)}
                className="absolute transform -translate-x-1/2 -translate-y-full flex flex-col items-center group transition-transform hover:scale-110 z-10"
                style={{ top: `${place.lat}%`, left: `${place.lng}%` }}
             >
                 <MapPinIcon className={`w-8 h-8 drop-shadow-md text-[#fe2c55]`} />
                 <div className="w-2 h-1 bg-black/30 rounded-full blur-[1px]"></div>
             </button>
         ))}

         {/* My Location */}
         <div className="absolute top-1/2 left-1/2 w-4 h-4 bg-blue-500 rounded-full border-2 border-white shadow-lg animate-pulse z-0"></div>
         <div className="absolute top-1/2 left-1/2 w-32 h-32 bg-blue-500/10 rounded-full transform -translate-x-1/2 -translate-y-1/2 pointer-events-none border border-blue-500/20"></div>
      </div>

      {/* Place Details */}
      {selectedPlace && (
          <div className="absolute bottom-0 left-0 right-0 z-40 p-2">
              <div className="bg-white rounded-2xl shadow-2xl overflow-hidden animate-slide-up">
                  <div className="flex p-4 gap-4">
                      <img src={selectedPlace.image} className="w-20 h-20 rounded-xl object-cover bg-gray-200" />
                      <div className="flex-1">
                          <h2 className="font-bold text-lg text-black">{selectedPlace.name}</h2>
                          <p className="text-gray-500 text-sm mb-2">{selectedPlace.category} • {selectedPlace.rating} ★</p>
                          <div className="flex gap-2">
                              <button className="bg-[#fe2c55] text-white px-4 py-2 rounded-lg font-bold text-xs flex-1">Go</button>
                              <button onClick={() => setSelectedPlace(null)} className="bg-gray-100 text-gray-600 px-4 py-2 rounded-lg font-bold text-xs">Close</button>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
