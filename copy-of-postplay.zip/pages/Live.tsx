
import React, { useState } from 'react';
import { UserProfile } from '../types';
import { HeartIcon, ShareIcon, MagicIcon, UserIcon, SwordsIcon, GiftIcon, XIcon } from '../components/Icons';

const MOCK_LIVES = [
  { id: '1', username: 'gamer_pro', viewers: 12500, title: 'Ranked Matches! 🎮', bg: 'https://picsum.photos/seed/gaming/400/800' },
  { id: '2', username: 'chill_beats', viewers: 4500, title: 'Study with me 📚', bg: 'https://picsum.photos/seed/study/400/800' },
  { id: '3', username: 'cooking_mama', viewers: 8900, title: 'Making Pasta from Scratch 🍝', bg: 'https://picsum.photos/seed/cooking/400/800' },
];

interface LiveProps {
    onBack?: () => void;
}

export const Live: React.FC<LiveProps> = ({ onBack }) => {
  const [currentLive, setCurrentLive] = useState(0);

  const handleBattleRequest = () => {
    // In a real app, this would trigger a socket event
    console.log('Requesting Live Battle...');
  };

  return (
    <div className="h-full w-full bg-black snap-y snap-mandatory overflow-y-scroll no-scrollbar relative">
      
      {/* Unique "Quit Live" Back Button - Top Right Glass Pill */}
      {onBack && (
          <div className="fixed top-6 right-4 z-50 animate-fade-in">
              <button 
                onClick={onBack}
                className="glass-capsule w-10 h-10 rounded-full flex items-center justify-center text-white hover:bg-white/20 transition-colors shadow-lg border border-white/20"
              >
                  <XIcon className="w-5 h-5 drop-shadow-md" />
              </button>
          </div>
      )}

      {MOCK_LIVES.map((live, index) => (
        <div key={live.id} className="h-full w-full snap-start relative bg-gray-900 overflow-hidden">
           {/* Background Video Simulation */}
           <img src={live.bg} className="absolute inset-0 w-full h-full object-cover opacity-60" />
           <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/90"></div>

           {/* Top Info Bar */}
           <div className="absolute top-24 left-4 right-16 flex items-center justify-between z-20 pointer-events-none">
              <div className="bg-black/30 backdrop-blur-md rounded-full p-1 pr-4 flex items-center gap-2 border border-white/10 pointer-events-auto">
                 <img src={`https://picsum.photos/seed/${live.username}/50`} className="w-9 h-9 rounded-full border border-white" />
                 <div className="flex flex-col">
                    <div className="font-bold text-white text-xs leading-tight">@{live.username}</div>
                    <div className="text-[9px] text-gray-300 flex items-center gap-1">
                        <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div> {live.viewers.toLocaleString()}
                    </div>
                 </div>
                 <button className="bg-[#800020] hover:bg-[#600018] text-white text-[10px] font-bold px-3 py-1 rounded-full ml-2">Follow</button>
              </div>
              
              {/* Live Rank/Title Badge */}
              <div className="bg-yellow-500/20 backdrop-blur-md border border-yellow-500/50 px-2 py-1 rounded text-[10px] font-bold text-yellow-400 pointer-events-auto">
                  Daily Rank #4
              </div>
           </div>

           {/* Center Right: Battle Button */}
           <div className="absolute right-4 top-1/2 transform -translate-y-1/2 flex flex-col gap-4 z-20 items-center pointer-events-auto">
               <button 
                 onClick={handleBattleRequest}
                 className="flex flex-col items-center gap-1 group"
               >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center border-2 border-white/20 shadow-lg animate-pulse group-active:scale-95 transition-transform">
                     <SwordsIcon className="w-5 h-5 text-white" />
                  </div>
                  <span className="text-[9px] font-bold text-white bg-black/40 px-2 py-0.5 rounded-full backdrop-blur-sm">PK</span>
               </button>
           </div>

           {/* Chat Overlay - Positioned higher to clear bottom nav */}
           <div className="absolute bottom-20 left-4 w-[70%] h-48 overflow-hidden mask-image-gradient z-10 pointer-events-none">
              <div className="flex flex-col justify-end h-full gap-2 text-sm text-white drop-shadow-md pb-2">
                 <div className="bg-black/20 rounded-lg p-1.5 self-start backdrop-blur-sm border border-white/5"><span className="font-bold text-gray-300 text-xs">user1:</span> <span className="text-xs">wow amazing!</span></div>
                 <div className="bg-black/20 rounded-lg p-1.5 self-start backdrop-blur-sm border border-white/5"><span className="font-bold text-yellow-400 text-xs">fan_boy:</span> <span className="text-xs">sent a Rose 🌹</span></div>
                 <div className="bg-black/20 rounded-lg p-1.5 self-start backdrop-blur-sm border border-white/5"><span className="font-bold text-gray-300 text-xs">new_here:</span> <span className="text-xs">how long have you been live?</span></div>
                 <div className="bg-[#fe2c55]/20 rounded-lg p-1.5 self-start backdrop-blur-sm border border-[#fe2c55]/30"><span className="font-bold text-[#fe2c55] text-xs">System:</span> <span className="text-xs">Welcome to the Live! Tap to like.</span></div>
              </div>
           </div>

           {/* Bottom Actions Row - Moved down to bottom-6 since Nav Bar is hidden in Live Mode */}
           <div className="absolute bottom-6 left-0 right-0 px-4 flex items-center gap-3 z-30 pointer-events-auto">
              <div className="flex-1 bg-black/40 backdrop-blur-md rounded-full h-10 px-4 flex items-center text-gray-400 text-sm border border-white/10 cursor-text hover:bg-black/60 transition-colors">
                 Say something...
              </div>
              
              <button className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white border border-white/10 active:bg-gray-800 transition-colors">
                 <UserIcon className="w-5 h-5" />
              </button>
              
              <button className="w-10 h-10 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white border border-white/10 active:bg-gray-800 transition-colors">
                 <ShareIcon className="w-5 h-5" />
              </button>
              
              <button className="w-10 h-10 rounded-full bg-gradient-to-tr from-[#800020] to-red-600 flex items-center justify-center text-white shadow-lg active:scale-95 transition-transform border border-white/20">
                 <GiftIcon className="w-5 h-5" />
              </button>
           </div>
        </div>
      ))}
    </div>
  );
};
