
import React, { useState, useEffect } from 'react';
import { Echo } from '../types';
import { cmd } from '../services/commands';
import { 
    BoltIcon, RepeatIcon, CommentIcon, ShareIcon, 
    BadgeCheckIcon, BadgeAlertIcon, FeatherIcon, PlusIcon, ChevronLeftIcon 
} from '../components/Icons';

const MOCK_ECHOS: Echo[] = [
    { 
        id: 'e1', creatorId: 'u1', username: 'TechInsider', handle: 'tech_insider', avatar: 'https://picsum.photos/seed/tech/100', 
        content: 'Just tested the new AI model. The latency is incredible. 🚀 #Tech #AI', 
        timestamp: Date.now() - 3600000, visibility: 'public', boostCount: 120, echoCount: 45, replyCount: 12,
        factCheckStatus: 'verified' 
    }
];

interface EchoFeedProps {
    onBack?: () => void;
}

export const EchoFeed: React.FC<EchoFeedProps> = ({ onBack }) => {
    const [echos, setEchos] = useState<Echo[]>(MOCK_ECHOS);

    useEffect(() => {
        const load = async () => {
            try {
                const data = await cmd.echo.flowline();
                if (data.length > 0) setEchos(data);
            } catch (e) { console.warn("Using mock echos"); }
        };
        load();
    }, []);

    const handleBoost = async (id: string) => {
        await cmd.echo.boost(id);
        setEchos(prev => prev.map(e => e.id === id ? { ...e, boostCount: e.boostCount + 1, isBoosted: true } : e));
    };

    return (
        <div className="h-full w-full bg-black text-white overflow-y-auto no-scrollbar pb-20 pt-20">
            {/* Header */}
            <div className="fixed top-0 left-0 right-0 h-16 bg-black/80 backdrop-blur-md z-10 flex items-center px-4 border-b border-white/10">
                {onBack && (
                    <button onClick={onBack} className="mr-4">
                        <ChevronLeftIcon className="w-6 h-6 text-white" />
                    </button>
                )}
                <h1 className="flex-1 text-center text-lg font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 pr-10">
                    CURRENT EVENTS
                </h1>
            </div>

            <div className="flex flex-col gap-4 p-4">
                {echos.map(echo => (
                    <div key={echo.id} className="glass-panel p-4 rounded-2xl border border-white/10 relative overflow-hidden group hover:border-white/20 transition-all">
                        {echo.isEcho && (
                            <div className="flex items-center gap-2 text-gray-400 text-xs font-bold mb-2">
                                <RepeatIcon className="w-3 h-3" />
                                <span>{echo.handle} echoed</span>
                            </div>
                        )}

                        <div className="flex gap-3">
                            <img src={echo.avatar} className="w-10 h-10 rounded-full border border-white/20 object-cover" />
                            <div className="flex-1">
                                <div className="flex items-center justify-between">
                                    <div className="flex flex-col">
                                        <div className="flex items-center gap-1">
                                            <span className="font-bold text-sm">{echo.username}</span>
                                            <span className="text-gray-500 text-xs">@{echo.handle}</span>
                                        </div>
                                    </div>
                                    {echo.factCheckStatus && (
                                        <div className={`px-2 py-0.5 rounded-full text-[9px] font-bold border border-green-500 text-green-400 bg-green-900/30`}>
                                            VERIFIED
                                        </div>
                                    )}
                                </div>

                                <p className="mt-2 text-sm leading-relaxed text-gray-200">{echo.content}</p>

                                <div className="flex items-center justify-between mt-4 pr-4">
                                    <button onClick={() => handleBoost(echo.id)} className={`flex items-center gap-1 ${echo.isBoosted ? 'text-yellow-400' : 'text-gray-500'}`}>
                                        <BoltIcon className="w-5 h-5" />
                                        <span className="text-xs font-bold">{echo.boostCount}</span>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
