
import React, { useState } from 'react';
import { ChevronLeftIcon, UserIcon, ShieldIcon, LockIcon, BagIcon, LiveIcon, CheckIcon } from '../components/Icons';
import { getCurrentUser } from '../services/auth';
import { settings } from '../services/settings';
import { cmd } from '../services/commands';

interface SettingsProps {
  onBack: () => void;
  onLogout: () => void;
  onNavigateToAdmin?: () => void;
}

// Glass Card for Grid
const SettingCard: React.FC<{ icon: React.ReactNode; label: string; color?: string; onClick: () => void }> = ({ icon, label, color, onClick }) => (
    <div onClick={onClick} className="glass-panel p-4 rounded-2xl flex flex-col items-center justify-center gap-3 aspect-square cursor-pointer active:scale-95 transition-transform border border-gray-100 shadow-sm hover:shadow-md bg-white">
        <div className={`p-3 rounded-full ${color || 'bg-gray-100 text-gray-600'}`}>
            {icon}
        </div>
        <span className="text-xs font-bold text-gray-800 text-center">{label}</span>
    </div>
);

export const Settings: React.FC<SettingsProps> = ({ onBack, onLogout, onNavigateToAdmin }) => {
  const [currentUser, setCurrentUser] = useState(getCurrentUser());
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const handleLogout = async () => {
      await settings.auth.logout();
      onLogout();
  };

  const handleSwitchToBrand = async () => {
      if (confirm('Switch to Brand Account? You will be able to upload products.')) {
          await cmd.creator.switchToBrand();
          alert('You are now a Brand!');
          setCurrentUser(getCurrentUser()); // Refresh local state
      }
  };

  const handleJoinCreator = async () => {
      await cmd.creator.join();
      alert('Welcome to the Creator Program! You can now Go Live.');
      setCurrentUser(getCurrentUser());
  };

  return (
    <div className="h-full w-full bg-gray-50 flex flex-col font-sans">
        {/* Header */}
        <div className="h-16 bg-white border-b border-gray-100 flex items-center px-4 justify-between">
            <button onClick={onBack} className="p-2 -ml-2 rounded-full hover:bg-gray-100">
                <ChevronLeftIcon className="w-6 h-6 text-black" />
            </button>
            <h1 className="font-black text-lg tracking-tight">Control Center</h1>
            <div className="w-8"></div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 pb-20">
            {/* Account Status Banner */}
            <div className="bg-black text-white p-6 rounded-3xl mb-6 shadow-xl relative overflow-hidden">
                <div className="relative z-10">
                    <h2 className="text-2xl font-bold mb-1">{currentUser?.username}</h2>
                    <p className="text-white/60 text-xs mb-4">{currentUser?.email}</p>
                    <div className="flex gap-2">
                        {currentUser?.isCreator && <span className="bg-[#fe2c55] px-2 py-1 rounded text-[10px] font-bold">CREATOR</span>}
                        {currentUser?.isBrand && <span className="bg-blue-500 px-2 py-1 rounded text-[10px] font-bold">BRAND</span>}
                        {isAdmin && <span className="bg-yellow-500 px-2 py-1 rounded text-[10px] font-bold text-black">ADMIN</span>}
                    </div>
                </div>
                <div className="absolute -right-4 -bottom-4 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
            </div>

            {/* Admin Portal (Conditional) */}
            {isAdmin && (
                <button onClick={onNavigateToAdmin} className="w-full mb-6 bg-yellow-400/20 border border-yellow-400/50 p-4 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                        <ShieldIcon className="w-6 h-6 text-yellow-600" />
                        <span className="font-bold text-yellow-800">Admin Portal</span>
                    </div>
                    <ChevronLeftIcon className="w-5 h-5 text-yellow-700 rotate-180" />
                </button>
            )}

            {/* Grid Layout */}
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Settings</h3>
            <div className="grid grid-cols-2 gap-3 mb-6">
                <SettingCard icon={<UserIcon className="w-6 h-6" />} label="Account" onClick={() => alert('Account Settings')} />
                <SettingCard icon={<LockIcon className="w-6 h-6" />} label="Privacy" onClick={() => alert('Privacy Settings')} />
                <SettingCard icon={<ShieldIcon className="w-6 h-6" />} label="Security" onClick={() => alert('Security Settings')} />
                <SettingCard icon={<BagIcon className="w-6 h-6" />} label="Orders" onClick={() => alert('Order History')} />
            </div>

            {/* Tools Section */}
            <h3 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Tools</h3>
            <div className="space-y-3 mb-6">
                {!currentUser?.isCreator && (
                    <button onClick={handleJoinCreator} className="w-full bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="bg-red-100 p-2 rounded-full"><LiveIcon className="w-5 h-5 text-red-500" /></div>
                            <div className="text-left">
                                <div className="font-bold text-sm text-gray-900">Join Creator Program</div>
                                <div className="text-[10px] text-gray-500">Unlock Live Streaming</div>
                            </div>
                        </div>
                        <div className="bg-black text-white text-xs font-bold px-3 py-1 rounded-full">Join</div>
                    </button>
                )}

                {!currentUser?.isBrand && (
                    <button onClick={handleSwitchToBrand} className="w-full bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <div className="bg-blue-100 p-2 rounded-full"><BagIcon className="w-5 h-5 text-blue-500" /></div>
                            <div className="text-left">
                                <div className="font-bold text-sm text-gray-900">Switch to Brand</div>
                                <div className="text-[10px] text-gray-500">Sell products on Shop</div>
                            </div>
                        </div>
                        <div className="bg-black text-white text-xs font-bold px-3 py-1 rounded-full">Switch</div>
                    </button>
                )}
            </div>

            <button onClick={handleLogout} className="w-full py-4 text-red-500 font-bold text-sm bg-white border border-gray-200 rounded-xl">
                Log Out
            </button>
            <p className="text-center text-[10px] text-gray-400 mt-6">PostPlays v2.1.0 (Production)</p>
        </div>
    </div>
  );
};
