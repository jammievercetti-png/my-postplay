
import { Place } from '../types';

const MOCK_PLACES: Place[] = [
  { id: 'p1', name: 'Joe\'s Pizza', category: 'Restaurant', address: '123 Main St', rating: 4.8, reviews: 1240, image: 'https://picsum.photos/seed/pizza/300/200', lat: 50, lng: 50, isOpen: true, priceLevel: '$$' },
  { id: 'p2', name: 'Central Park Cafe', category: 'Cafe', address: '45 Park Ln', rating: 4.5, reviews: 890, image: 'https://picsum.photos/seed/cafe/300/200', lat: 40, lng: 60, isOpen: true, priceLevel: '$' },
  { id: 'p3', name: 'Skyline Gym', category: 'Gym', address: '88 High Rd', rating: 4.9, reviews: 450, image: 'https://picsum.photos/seed/gym/300/200', lat: 70, lng: 30, isOpen: false, priceLevel: '$$$' },
  { id: 'p4', name: 'Sunset Beach', category: 'Sights', address: 'Ocean Blvd', rating: 5.0, reviews: 2300, image: 'https://picsum.photos/seed/beach/300/200', lat: 20, lng: 80, isOpen: true, priceLevel: 'Free' },
  { id: 'p5', name: 'Downtown Sushi', category: 'Restaurant', address: '5th Ave', rating: 4.7, reviews: 560, image: 'https://picsum.photos/seed/sushi/300/200', lat: 60, lng: 45, isOpen: true, priceLevel: '$$$' },
];

export const getPopularPlaces = (): Place[] => MOCK_PLACES;

export const searchPlaces = (query: string): Place[] => {
  if (!query) return MOCK_PLACES;
  const lowerQ = query.toLowerCase();
  return MOCK_PLACES.filter(p => p.name.toLowerCase().includes(lowerQ) || p.category.toLowerCase().includes(lowerQ));
};
