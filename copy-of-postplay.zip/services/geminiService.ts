import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateViralCaption = async (context: string, tone?: string): Promise<string> => {
  try {
    const toneInstruction = tone ? `Make the tone ${tone}.` : 'Make it engaging and viral.';
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Create a viral, short, punchy caption for a TikTok video about: "${context}". 
      ${toneInstruction}
      Include 3-4 trending hashtags. Do not include quotes around the output. 
      Keep it under 30 words.`,
    });
    
    return response.text || "";
  } catch (error) {
    console.error("Error generating caption:", error);
    return "Check out this video! #viral #fyp";
  }
};